┌───┐                   ┌┐   ┌───┐    ┌┐  ┌─┐
│┌─┐│        ┌┐        ┌┘└┐  │┌─┐│    ││  │┌┘
│└─┘│┌─┐┌──┐ └┘┌──┐┌──┐└┐┌┘┌┐││ └┘┌──┐││ ┌┘└┐
│┌──┘│┌┘│┌┐│ ┌┐││─┤│┌─┘ ││ └┘││┌─┐│┌┐│││ └┐┌┘
││   ││ │└┘│ ││││─┤│└─┐ │└┐┌┐│└┴─││└┘││└┐ ││ 
└┘   └┘ └──┘ ││└──┘└──┘ └─┘└┘└───┘└──┘└─┘ └┘ 
            ┌┘│                              
            └─┘                              
╔════════════════════════════════════════════════════════╗
║Team: Code 404		Class: CSD1400E            		     ║
║Members:                                                ║
║	Warren Ang Jun Xuan (a.warrenjunxuan@digipen.edu)    ║
║	Desmond Peh Han Yong (desmondhanyong.peh@digipen.edu)║
║	Sarah Tan Yu Hong (sarahyuhong.t@digipen.edu)    	 ║
╚════════════════════════════════════════════════════════╝

Special Obsticale:
	Water     : when the ball enter the water will reset 
				to the previous location
	Tunnel    : will Tranport the ball to the other entrence
	Sand      : will slow down the ball
	Wind Zone : Will redirect the ball

Instructions:
	Click and drag the ball away the target 