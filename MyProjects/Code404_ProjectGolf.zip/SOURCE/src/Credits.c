/*---------------------------------------------------------
 * file:	Credits.c
 * author:	Sarah Tan Yu Hong
 * email:	sarahyuhong.t@digipen.edu
 *
 * brief:	This file contain functions that help to create the game credits.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h> 
#include "cprocessing.h"
#include "mouseinput.h"
#include "SceneManager.h"
#include "Credits.h"
#include "Audio.h"

#define BUTTON_WIDTH 230.f
#define BUTTON_HEIGHT 60.f


CP_Vector gMainMenuButtonPosition;
CP_Vector gNextButtonPosition;
CP_Vector buttonSize;
CP_Vector nextButtonSize;


CP_Color gButtonColor;
#define BUTTON_TYPE_MAINMENU 0
#define BUTTON_TYPE_NEXT 1
int gCurrentButtonType;
#define COLOR_GREEN CP_Color_Create(0, 255, 0, 255)
#define COLOR_WHITE CP_Color_Create(255, 255, 255, 255)

typedef struct _Particle
{
	CP_Vector pos;
	CP_Vector vel;
	CP_Color* color;
} Particle;

const float EPSILON = 0.0000001f;

Particle particles[30];
int numParticles = 30, nextLevel;

float circleProximityDistance = 100.0f;

CP_Color color;

CP_Color randomColors[] = {
	{ 128, 0,   0,   255 },
	{ 128, 128, 0,   255 },
	{ 0,   128, 0,   255 },
	{ 0,   128, 128, 255 },
	{ 0,   0,   128, 255 },
	{ 128, 0,   128, 255 } };

void ParticleCreate(Particle* part) {

	part->pos.x = CP_Random_RangeFloat(0, (float)CP_System_GetWindowWidth());
	part->pos.y = CP_Random_RangeFloat(0, (float)CP_System_GetWindowHeight());
	part->vel.x = CP_Random_RangeFloat(-150, 150);
	part->vel.y = CP_Random_RangeFloat(-150, 150);
	part->color = &randomColors[CP_Random_RangeInt(0, 5)];
}


void ParticleUpdate(Particle* part)
{

	// move particle based on velocity and correct for wall collisions
	float time = CP_System_GetDt();
	float timeX = time;
	float timeY = time;

	while (time > EPSILON)
	{
		int collisionX = FALSE;
		int collisionY = FALSE;

		float newPosX = part->pos.x + part->vel.x * time;
		float newPosY = part->pos.y + part->vel.y * time;
		float newTime = time;

		// check wall collisions X and Y
		if (newPosX <= 0)
		{
			timeX = part->pos.x / (part->pos.x - newPosX) * time;
			collisionX = TRUE;
		}
		else if (newPosX >= CP_System_GetWindowWidth())
		{
			timeX = (CP_System_GetWindowWidth() - part->pos.x) / (newPosX - part->pos.x) * time;
			collisionX = TRUE;
		}

		if (newPosY <= 0)
		{
			timeY = part->pos.y / (part->pos.y - newPosY) * time;
			collisionY = TRUE;
		}
		else if (newPosY >= CP_System_GetWindowHeight())
		{
			timeY = (CP_System_GetWindowHeight() - part->pos.y) / (newPosY - part->pos.y) * time;
			collisionY = TRUE;
		}

		// resolve collisions
		if ((collisionX == TRUE) || (collisionY == TRUE))
		{

			// take the nearest time
			if (timeX < timeY)
			{
				newTime = timeX;
			}
			else
			{
				newTime = timeY;
			}

			// move the particle
			part->pos.x += part->vel.x * newTime;
			part->pos.y += part->vel.y * newTime;

			// flip velocity vectors to reflect off walls
			if ((collisionX == TRUE) && (collisionY == FALSE))
			{
				part->vel.x *= -1;
			}
			else if ((collisionX == FALSE) && (collisionY == TRUE))
			{
				part->vel.y *= -1;
			}
			else
			{	// they must both be colliding for this condition to occur
				if (timeX < timeY)
				{
					part->vel.x *= -1;
				}
				else if (timeX > timeY)
				{
					part->vel.y *= -1;
				}
				else
				{	// they must be colliding at the same time (ie. a corner)
					part->vel.x *= -1;
					part->vel.y *= -1;
				}
			}

			// decrease time and iterate
			time -= newTime;
		}
		else
		{
			// no collision
			part->pos.x = newPosX;
			part->pos.y = newPosY;
			time = 0;
		}
	}
}


void Credits_init(void)
{
    for (int i = 0; i < numParticles; ++i) {
        ParticleCreate(&particles[i]);
    }
    gButtonColor = COLOR_WHITE;

	nextLevel = 0;
	CP_Settings_RectMode(CP_POSITION_CENTER);
    gMainMenuButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .800f, CP_System_GetWindowWidth() * .900f);
    gNextButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .890f, CP_System_GetWindowWidth() * .410f);

	buttonSize = CP_Vector_Set(BUTTON_WIDTH, BUTTON_HEIGHT);
	nextButtonSize = CP_Vector_Set(100, BUTTON_HEIGHT);
}

void Credits_update(void)
{
	Credits_HandleInput();
	Credits_Update();
	Credits_Render();
	SceneManagerRenderBlack();
    Credits_HoverButton();
}

void Credits_exit(void)
{
	if (!nextLevel)
		Free_Sound();
}

void Credits_HandleInput()
{
	if (SceneManager_IsTransitioning())
		return;

	CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
	if (CP_Input_MouseTriggered(MOUSE_BUTTON_1))
	{
		//Back to Main Menu
		if (Detect_button(mousePos, gMainMenuButtonPosition, buttonSize))
		{
			SceneManagerSetNextScene(MainMenuScene);
			nextLevel = 1;
		}
		else if (Detect_button(mousePos, gNextButtonPosition, nextButtonSize)) {
			SceneManagerSetNextScene(Credit2_Scene);
			nextLevel = 1;

		}

	}
}

void Credits_HoverButton(void) {
    gButtonColor = COLOR_WHITE;
    CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());

    if (Detect_button(mousePos, gMainMenuButtonPosition, buttonSize))
    {
        gButtonColor = COLOR_GREEN;
        gCurrentButtonType = BUTTON_TYPE_MAINMENU;

    }

    else if (Detect_button(mousePos, gNextButtonPosition, nextButtonSize))
    {
        gButtonColor = COLOR_GREEN;
        gCurrentButtonType = BUTTON_TYPE_NEXT;
    }

}

void Credits_Update(void)
{
	SceneManagerUpdate();
}

void Credits_Render(void)
{

	if (SceneManager_GetOverlayPercentage() < 1.f)
	{
		CP_Settings_BlendMode(CP_BLEND_ALPHA);
		CP_Graphics_ClearBackground(CP_Color_Create(0, 0, 0, 255));
		CP_Settings_NoStroke();

		for (int i = 0; i < numParticles; ++i)
		{
			ParticleUpdate(&particles[i]);
		}

		//CP_Settings_BlendMode(CP_BLEND_ADD);
		CP_Settings_StrokeWeight(3);


		for (int i = 0; i < numParticles; ++i)
		{


			for (int j = i + 1; j < numParticles; ++j)
			{
				float distX = (float)fabsf(particles[i].pos.x - particles[j].pos.x);
				float distY = (float)fabsf(particles[i].pos.y - particles[j].pos.y);
				if (distX < circleProximityDistance && distY < circleProximityDistance)
				{
					color.r = particles[i].color->r + particles[j].color->r;
					color.g = particles[i].color->g + particles[j].color->g;
					color.b = particles[i].color->b + particles[j].color->b;
					color.a = (unsigned char)(255.0f * min(1.0f, (circleProximityDistance - max(distX, distY)) / (circleProximityDistance * 0.3f)));
					CP_Settings_Stroke(color);
					CP_Graphics_DrawCircle(particles[i].pos.x, particles[i].pos.y, 20);
				}
			}
		}
		CP_Settings_Stroke(CP_Color_Create(0, 0, 0, 255));
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		CP_Settings_TextSize(20.f);
		CP_Font_DrawText("All content (c) 2021 DigiPen Institute of Technology Singapore, all rights reserved", 50, 20);

		/* This will set the 'fill' with white color */
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		CP_Settings_TextSize(70.f);
		CP_Font_DrawText("Credits", CP_System_GetWindowWidth() * .35f, CP_System_GetWindowHeight() * .15f);

    
        CP_Settings_Fill(CP_Color_Create(128, 128, 0, 255));
        CP_Settings_TextSize(40.f);
        CP_Font_DrawText("A game created by Code404 Team", CP_System_GetWindowWidth() * .15f, CP_System_GetWindowHeight() * .22f);
        CP_Settings_Fill(CP_Color_Create(0, 255, 0, 255));
        CP_Font_DrawText("TEAM MEMBERS", CP_System_GetWindowWidth() * .30f, CP_System_GetWindowHeight() * .30f);

        /* This will set the 'fill' with white color */
        CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
        CP_Settings_TextSize(30.f);
        CP_Font_DrawText("WARREN ANG JUN XUAN", CP_System_GetWindowWidth() * .28f, CP_System_GetWindowHeight() * .35f);
        CP_Font_DrawText("DESMOND PEH HAN YONG", CP_System_GetWindowWidth() * .27f, CP_System_GetWindowHeight() * .40f);
        CP_Font_DrawText("SARAH TAN YU HONG", CP_System_GetWindowWidth() * .30f, CP_System_GetWindowHeight() * .45f);

		/* This will set the 'fill' with purple color */
		CP_Settings_Fill(CP_Color_Create(127, 0, 255, 255));
		CP_Settings_TextSize(40.f);
		CP_Font_DrawText("INSTRUCTORS", CP_System_GetWindowWidth() * .33f, CP_System_GetWindowHeight() * .55f);
		/* This will set the 'fill' with white color */
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		CP_Settings_TextSize(30.f);
		CP_Font_DrawText("DING XIANG CHENG", CP_System_GetWindowWidth() * .33f, CP_System_GetWindowHeight() * .60f);
		CP_Font_DrawText("GERALD WONG", CP_System_GetWindowWidth() * .35f, CP_System_GetWindowHeight() * .65f);

		/* This will set the 'fill' with red color */
		CP_Settings_Fill(CP_Color_Create(255, 0, 0, 255));
		CP_Settings_TextSize(40.f);
		CP_Font_DrawText("Created at", CP_System_GetWindowWidth() * .37f, CP_System_GetWindowHeight() * .75f);
		/* This will set the 'fill' with white color */
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 325));
		CP_Settings_TextSize(30.f);
		CP_Font_DrawText("DigiPen Institute of Technology Singapore", CP_System_GetWindowWidth() * .15f, CP_System_GetWindowHeight() * .80f);

        /* This will set the 'fill' to white color */
        CP_Settings_Fill(COLOR_WHITE);

		CP_Graphics_DrawRect(gNextButtonPosition.x, gNextButtonPosition.y, 100, BUTTON_HEIGHT);

		CP_Graphics_DrawRect(gMainMenuButtonPosition.x, gMainMenuButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);

        if (gCurrentButtonType == BUTTON_TYPE_NEXT)
        {
            CP_Settings_Fill(gButtonColor);
            CP_Graphics_DrawRect(gNextButtonPosition.x, gNextButtonPosition.y, 100, BUTTON_HEIGHT);
        }
        if (gCurrentButtonType == BUTTON_TYPE_MAINMENU)
        {
            CP_Settings_Fill(gButtonColor);
            CP_Graphics_DrawRect(gMainMenuButtonPosition.x, gMainMenuButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
        }
        /* This will set the 'fill' with black color */
        CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
        CP_Font_DrawText("Next", gNextButtonPosition.x - 25.f, gNextButtonPosition.y);
        CP_Font_DrawText("Exit to Main Menu", gMainMenuButtonPosition.x - 100.f, gMainMenuButtonPosition.y);
    }
}

