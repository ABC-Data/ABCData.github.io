/*---------------------------------------------------------
 * file:	main.c
 * author:	[NAME]
 * email:	[DIGIPEN EMAIL ADDRESS]
 * 
 * brief:	Main entry point for the sample project
			* of the CProcessing library
 * 
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 * 
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/
#include <stdio.h>
#include "cprocessing.h"
#include "SceneManager.h"
#include "SplashScene.h"


/* Forward declarations */
/* Entry point */
int main(void)
{
    SceneManagerInit();
    CP_Engine_SetNextGameState(SplashScene_init, SplashScene_update, SplashScene_exit);
    CP_Engine_Run();
    return 0;
}
