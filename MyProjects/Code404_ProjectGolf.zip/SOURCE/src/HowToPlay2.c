/*---------------------------------------------------------
 * file:	HowToPlay2.c
 * author:	Sarah Tan Yu Hong
 * email:	sarahyuhong.t@digipen.edu
 *
 * brief:	This file contain functions that help to create the how to play section of the game which
		    indicate the rule of game and the controls.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h> 
#include "cprocessing.h"
#include "mouseinput.h"
#include "SceneManager.h"
#include "Audio.h"
#include "HowToPlay2.h"

#define BUTTON_WIDTH 230.f
#define BUTTON_HEIGHT 60.f


CP_Vector gMainMenuButtonPosition;

CP_Vector buttonSize;

CP_Color gButtonColor;
#define BUTTON_TYPE_MAINMENU 0
int gCurrentButtonType;
#define COLOR_GREEN CP_Color_Create(0, 255, 0, 255)
#define COLOR_WHITE CP_Color_Create(255, 255, 255, 255)

typedef struct _Particle
{
	CP_Vector pos;
	CP_Vector vel;
	CP_Color* color;
} Particle;

const float EPSILON5 = 0.0000001f;

Particle particles[30];
int numParticles5 = 30, nextLevel;

float circleProximityDistance5 = 100.0f;

CP_Color color;

CP_Color randomColors5[] = {
	{ 128, 0,   0,   255 },
	{ 128, 128, 0,   255 },
	{ 0,   128, 0,   255 },
	{ 0,   128, 128, 255 },
	{ 0,   0,   128, 255 },
	{ 128, 0,   128, 255 } };

void ParticleCreate5(Particle* part) {

	part->pos.x = CP_Random_RangeFloat(0, (float)CP_System_GetWindowWidth());
	part->pos.y = CP_Random_RangeFloat(0, (float)CP_System_GetWindowHeight());
	part->vel.x = CP_Random_RangeFloat(-150, 150);
	part->vel.y = CP_Random_RangeFloat(-150, 150);
	part->color = &randomColors5[CP_Random_RangeInt(0, 5)];
}


void ParticleUpdate5(Particle* part)
{

	// move particle based on velocity and correct for wall collisions
	float time = CP_System_GetDt();
	float timeX = time;
	float timeY = time;

	while (time > EPSILON5)
	{
		int collisionX = FALSE;
		int collisionY = FALSE;

		float newPosX = part->pos.x + part->vel.x * time;
		float newPosY = part->pos.y + part->vel.y * time;
		float newTime = time;

		// check wall collisions X and Y
		if (newPosX <= 0)
		{
			timeX = part->pos.x / (part->pos.x - newPosX) * time;
			collisionX = TRUE;
		}
		else if (newPosX >= CP_System_GetWindowWidth())
		{
			timeX = (CP_System_GetWindowWidth() - part->pos.x) / (newPosX - part->pos.x) * time;
			collisionX = TRUE;
		}

		if (newPosY <= 0)
		{
			timeY = part->pos.y / (part->pos.y - newPosY) * time;
			collisionY = TRUE;
		}
		else if (newPosY >= CP_System_GetWindowHeight())
		{
			timeY = (CP_System_GetWindowHeight() - part->pos.y) / (newPosY - part->pos.y) * time;
			collisionY = TRUE;
		}

		// resolve collisions
		if ((collisionX == TRUE) || (collisionY == TRUE))
		{

			// take the nearest time
			if (timeX < timeY)
			{
				newTime = timeX;
			}
			else
			{
				newTime = timeY;
			}

			// move the particle
			part->pos.x += part->vel.x * newTime;
			part->pos.y += part->vel.y * newTime;

			// flip velocity vectors to reflect off walls
			if ((collisionX == TRUE) && (collisionY == FALSE))
			{
				part->vel.x *= -1;
			}
			else if ((collisionX == FALSE) && (collisionY == TRUE))
			{
				part->vel.y *= -1;
			}
			else
			{	// they must both be colliding for this condition to occur
				if (timeX < timeY)
				{
					part->vel.x *= -1;
				}
				else if (timeX > timeY)
				{
					part->vel.y *= -1;
				}
				else
				{	// they must be colliding at the same time (ie. a corner)
					part->vel.x *= -1;
					part->vel.y *= -1;
				}
			}

			// decrease time and iterate
			time -= newTime;
		}
		else
		{
			// no collision
			part->pos.x = newPosX;
			part->pos.y = newPosY;
			time = 0;
		}
	}
}




void HowToPlay2_init(void)
{

    for (int i = 0; i < numParticles5; ++i) {
        ParticleCreate5(&particles[i]);
    }

    gButtonColor = COLOR_WHITE;
	nextLevel = 0;
	CP_Settings_RectMode(CP_POSITION_CENTER);
	gMainMenuButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .800f, CP_System_GetWindowWidth() * .900f);

	buttonSize = CP_Vector_Set(BUTTON_WIDTH, BUTTON_HEIGHT);
}

void HowToPlay2_update(void)
{

	HowToPlay2_HandleInput();
	HowToPlay2_Update();
	HowToPlay2_Render();
	SceneManagerRenderBlack();
    HowToPlay2_HoverButton();
}

void HowToPlay2_exit(void)
{
	if (!nextLevel)
		Free_Sound();
}

void HowToPlay2_HandleInput()
{
	if (SceneManager_IsTransitioning())
		return;

	CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
	if (CP_Input_MouseTriggered(MOUSE_BUTTON_1))
	{
		//Back to Main Menu
		if (Detect_button(mousePos, gMainMenuButtonPosition, buttonSize))
		{
			SceneManagerSetNextScene(MainMenuScene);
			nextLevel = 1;
		}

	}
}

void HowToPlay2_HoverButton(void) {
    gButtonColor = COLOR_WHITE;
    CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
    
    if (Detect_button(mousePos, gMainMenuButtonPosition, buttonSize))
    {
        gButtonColor = COLOR_GREEN;
        gCurrentButtonType = BUTTON_TYPE_MAINMENU;

    }

}

void HowToPlay2_Update(void)
{
	SceneManagerUpdate();
}

void HowToPlay2_Render(void)
{

	if (SceneManager_GetOverlayPercentage() < 1.f)
	{


		CP_Settings_BlendMode(CP_BLEND_ALPHA);
		CP_Graphics_ClearBackground(CP_Color_Create(0, 0, 0, 255));


		for (int i = 0; i < numParticles5; ++i)
		{
			ParticleUpdate5(&particles[i]);
		}

		/* CP_Settings_BlendMode(CP_BLEND_ADD);*/
		CP_Settings_StrokeWeight(3);


		for (int i = 0; i < numParticles5; ++i)
		{

			for (int j = i + 1; j < numParticles5; ++j)
			{
				float distX = (float)fabsf(particles[i].pos.x - particles[j].pos.x);
				float distY = (float)fabsf(particles[i].pos.y - particles[j].pos.y);
				if (distX < circleProximityDistance5 && distY < circleProximityDistance5)
				{
					color.r = particles[i].color->r + particles[j].color->r;
					color.g = particles[i].color->g + particles[j].color->g;
					color.b = particles[i].color->b + particles[j].color->b;
					color.a = (unsigned char)(255.0f * min(1.0f, (circleProximityDistance5 - max(distX, distY)) / (circleProximityDistance5 * 0.3f)));
					CP_Settings_Stroke(color);
					CP_Graphics_DrawCircle(particles[i].pos.x, particles[i].pos.y, 20);
				}
			}
		}

		/* This will set the 'fill' with white color */
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		CP_Settings_TextSize(70.f);
		CP_Font_DrawText("How to Play", CP_System_GetWindowWidth() * .30f, CP_System_GetWindowHeight() * .10f);


		CP_Settings_Fill(CP_Color_Create(127, 0, 255, 255));
		CP_Settings_TextSize(40.f);
        CP_Font_DrawText("Types of obstacles", CP_System_GetWindowWidth() * .31f, CP_System_GetWindowHeight() * .20f);
        CP_Settings_TextSize(30.f);
        CP_Settings_Fill(CP_Color_Create(160, 82, 45, 255));
        CP_Font_DrawText("Wall - block the path to the hole ", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .30f);
        CP_Font_DrawText("Wall", gMainMenuButtonPosition.x - 500.f, gMainMenuButtonPosition.y - 180.f);
        CP_Graphics_DrawRect(gMainMenuButtonPosition.x - 470.f, gMainMenuButtonPosition.y - 150.f, 120, 20);

		CP_Settings_Fill(CP_Color_Create(0, 0, 255, 255));
		CP_Font_DrawText("Water - results in the ball going out-of-bounds ", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .35f);
		CP_Font_DrawText("Water", gMainMenuButtonPosition.x - 265.f, gMainMenuButtonPosition.y - 180.f);
		CP_Graphics_DrawRect(gMainMenuButtonPosition.x - 230.f, gMainMenuButtonPosition.y - 135.f, 120, 50);

		CP_Settings_Fill(CP_Color_Create(222, 184, 65, 255));
		CP_Font_DrawText("Sand - hinders the ball by slowing it down ", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .40f);
		CP_Font_DrawText("Sand", gMainMenuButtonPosition.x - 10.f, gMainMenuButtonPosition.y - 180.f);
		CP_Graphics_DrawRect(gMainMenuButtonPosition.x + 20.f, gMainMenuButtonPosition.y - 135.f, 120, 50);

		CP_Settings_Fill(CP_Color_Create(50, 205, 50, 255));
		CP_Font_DrawText("Wind zone - pushes the ball in another direction", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .45f);
		CP_Font_DrawText("Wind", gMainMenuButtonPosition.x - 500.f, gMainMenuButtonPosition.y - 70.f);
		CP_Graphics_DrawRect(gMainMenuButtonPosition.x - 470.f, gMainMenuButtonPosition.y - 30.f, 120, 50);

		CP_Settings_Fill(CP_Color_Create(128, 128, 128, 255));
		CP_Font_DrawText("Tunnels - teleports the ball to another tunnel and spits ", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .50f);
		CP_Font_DrawText("the ball out in a different direction ", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .55f);
		CP_Font_DrawText("Tunnel", gMainMenuButtonPosition.x - 265.f, gMainMenuButtonPosition.y - 70.f);
		CP_Graphics_DrawCircle(gMainMenuButtonPosition.x - 230.f, gMainMenuButtonPosition.y - 30.f, 50);

       
        /* This will set the 'fill' to white color */
        CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
        CP_Settings_Stroke(CP_Color_Create(255, 255, 255, 255));
        CP_Settings_Fill(COLOR_WHITE);
        CP_Graphics_DrawRect(gMainMenuButtonPosition.x, gMainMenuButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);

        if (gCurrentButtonType == BUTTON_TYPE_MAINMENU)
        {
            CP_Settings_Fill(gButtonColor);
            CP_Graphics_DrawRect(gMainMenuButtonPosition.x, gMainMenuButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
        }
       
        /* This will set the 'fill' with black color */
        CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));

        CP_Font_DrawText("Exit to Main Menu", gMainMenuButtonPosition.x - 100.f, gMainMenuButtonPosition.y);
       
	}
}

