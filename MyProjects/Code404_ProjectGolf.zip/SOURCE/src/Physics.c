﻿/*---------------------------------------------------------
 * file:	Physics.c
 * author:	Warren Ang Jun Xuan
 * email:	a.warrenjunxuan@digipen.edu
 *
 * brief:	Calculation of ball acceleration.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/
#include "Physics.h"

void Update_Velocity(CP_Vector* ballVel, int onSand)
{
	float dt = CP_System_GetDt();
	float slowDownrate = (DECEL + onSand * FRICTION) * dt;
	//if velocity is less than slowDownrate
	if (CP_Vector_Length(*ballVel) != 0 && CP_Vector_Length(*ballVel) < slowDownrate * slowDownrate)
	{
		//set velocity to zero 
		*ballVel = CP_Vector_Zero();
	}
	//if velocity is more than slowDownrate, continue to decrease velocity 
	else
	{
		//scale deceleration with dt to get deceleration per frame, then take velocity and add deceleration to make ball slower per frame
		*ballVel = CP_Vector_Subtract(*ballVel, CP_Vector_Scale(CP_Vector_Negate(CP_Vector_Normalize(*ballVel)), slowDownrate));
	}
}