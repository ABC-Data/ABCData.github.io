/*---------------------------------------------------------
 * file:	Warren_Level.h
 * author:	Warren Ang Jun Xuan
 * email:	a.warrenjunxuan@digipen.edu
 *
 * brief:	Level 3 of game.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/

#pragma once
void Warren_init(void);
void Warren_update(void);
void Warren_exit(void);