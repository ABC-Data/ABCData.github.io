﻿/*---------------------------------------------------------
 * file:	SplashScene.c
 * author:	Desmond peh han yong
 * email:	desmondhanyong.peh@digipen.edu
 *
 * brief:	Various scene functions
 *
 * Copyright @ 2021 DigiPen, All rights reserved.
 *---------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h> 
#include "cprocessing.h"
#include "SplashScene.h"
#include "Audio.h"
#include "SceneManager.h"
#include "easing.h"

CP_Vector  contentPos, CopyrightPos;
float timer, digiAlphaTimer, titleAlphaTimer;
CP_Image spriteSheetImage, gameName, logo;
int nextLevel = 0;
void SplashScene_Update(void);
void SplashScene_Render(void);
void SplashScene_init(void)
{
	CP_Settings_RectMode(CP_POSITION_CENTER);
	CP_Settings_TextAlignment(CP_TEXT_ALIGN_H_CENTER, CP_TEXT_ALIGN_V_MIDDLE);
	spriteSheetImage = CP_Image_Load("./Assets/DigiPen_Singapore_WHITE.png");
	gameName = CP_Image_Load("./Assets/gameName.png");
	logo = CP_Image_Load("./Assets/logo.png");
	CP_System_SetFrameRate(60);
	CP_System_SetWindowSize(720, 720);
	timer = 0;
	Audio_Init();
	contentPos = CP_Vector_Set(CP_System_GetWindowWidth() * .5f, CP_System_GetWindowHeight() * .4f);
	CopyrightPos = CP_Vector_Set(CP_System_GetWindowWidth() * .5f, CP_System_GetWindowHeight() * .85f);
}

void SplashScene_update(void)
{
	SplashScene_Update();
	SplashScene_Render();
	SceneManagerUpdate();
}

void SplashScene_exit(void)
{
	CP_Settings_TextAlignment(CP_TEXT_ALIGN_H_LEFT, CP_TEXT_ALIGN_V_MIDDLE);
	CP_Image_Free(&spriteSheetImage);
	if (!nextLevel)
		Free_Sound();
}

void SplashScene_Update(void)
{
	if (timer >= 16)
		return;
	timer += CP_System_GetDt();
	if (timer >= 16)
	{
		SceneManagerSetNextScene(MainMenuScene);
		nextLevel = 1;
		return;
	}
	digiAlphaTimer = timer / 4.f;
	if (digiAlphaTimer > 2)
		digiAlphaTimer = 2;
	if (digiAlphaTimer < 0)
		digiAlphaTimer = 0;
	titleAlphaTimer = (timer - 8) / 4.f;
	if (titleAlphaTimer > 2)
		titleAlphaTimer = 2;
	if (titleAlphaTimer < 0)
		titleAlphaTimer = 0;
}

void SplashScene_Render(void)
{
	if (SceneManager_GetOverlayPercentage() < 1.f)
	{
		CP_Graphics_ClearBackground(CP_Color_Create(0, 0, 0, 255));
		CP_Image_Draw(spriteSheetImage, contentPos.x, contentPos.y, 1525 * .35f, 445 * .35f, (int)(255 * EaseInOutQuad(0, 1, digiAlphaTimer)));

		CP_Settings_TextSize(80);

		CP_Image_Draw(gameName, contentPos.x - 50, contentPos.y, 500, 200, (int)(255 * EaseInOutQuad(0, 1, titleAlphaTimer)));
		CP_Image_Draw(logo, contentPos.x + 250, contentPos.y + 25, 150, 130, (int)(255 * EaseInOutQuad(0, 1, titleAlphaTimer)));

		CP_Settings_TextSize(20);
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		CP_Font_DrawText("All content (C) 2021 DigiPen Institute of Technology Singapore. All Rights Reserved", CopyrightPos.x, CopyrightPos.y);
	}
	SceneManagerRenderBlack();
}