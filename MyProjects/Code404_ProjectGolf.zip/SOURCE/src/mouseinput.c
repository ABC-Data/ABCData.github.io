﻿/*---------------------------------------------------------
 * file:	mouseinput.c
 * author:	Warren Ang Jun Xuan
 * email:	a.warrenjunxuan@digipen.edu
 *
 * brief:	Detection of mouse click on ball/button.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/
#include "mouseinput.h"
int hitNo;

int Detect_ball(CP_Vector mousePos, CP_Vector ballPos, float ballSize)
{
	CP_Vector RP = CP_Vector_Subtract(mousePos, ballPos);
	return CP_Vector_Length(RP) < ballSize;
}

int Detect_button(CP_Vector mousePos, CP_Vector buttonPos, CP_Vector buttonSize)
{
	CP_Vector N = CP_Vector_Set(0, 1);
	CP_Vector NP = CP_Vector_Set(N.y, -N.x);
	CP_Vector RP = CP_Vector_Subtract(mousePos, buttonPos);

	return (fabsf(CP_Vector_DotProduct(RP, N)) < buttonSize.y * 0.5f && fabsf(CP_Vector_DotProduct(RP, NP)) < buttonSize.x * 0.5f);
}