﻿/*---------------------------------------------------------
 * file:	SceneManager.h
 * author:	Desmond peh han yong
 * email:	desmondhanyong.peh@digipen.edu
 *
 * brief:	Declaration of Scene Manager Functions
 *
 * Copyright @ 2021 DigiPen, All rights reserved.
 *---------------------------------------------------------*/
#pragma once
#include "cprocessing.h"

typedef enum SceneIndex
{
	SplashScene = 0,
	MainMenuScene = 1,
	Option_Scene = 2,
	HowToPlay_Scene = 3,
	HowToPlay2_Scene = 4,
	Credit_Scene = 5,
	Credit2_Scene = 6,
	Level_One = 7,
	Level_Two = 8,
	Level_Three = 9,
	Total_Scene = 10
}SceneIndex;

void SceneManagerUpdate(void);
void SceneManagerInit(void);
int SceneManager_IsTransitioning(void);
SceneIndex SceneManagerGetCurrentIndex();
void SceneManagerSetNextScene(SceneIndex index);
void SceneManagerRenderBlack(void);

float SceneManager_GetOverlayPercentage(void);
