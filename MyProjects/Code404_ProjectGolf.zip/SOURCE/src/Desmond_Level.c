﻿/*---------------------------------------------------------
 * file:	Desmond_level.c
 * author:	Desmond peh han yong
 * email:	desmondhanyong.peh@digipen.edu
 *
 * brief:	Various scene functions
 *
 * Copyright @ 2021 DigiPen, All rights reserved.
 *---------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h> 
#include "cprocessing.h"
#include "mouseinput.h"
#include "Desmond_Level.h"
#include "SceneManager.h"
#include "Physics.h"
#include "Audio.h"
#include "GameObject.h"

#define GAMEOBJECTSIZE 40
#define MAXBALLSPEED 300.f
#define MAXHIT 12
#define TRUE 1
#define FALSE 0
#define BUTTON_WIDTH 230.f
#define BUTTON_HEIGHT 60.f
GameObject** gameobjectList;
GameObject* player;
GameObject* goal;
int gIsPaused, hitNo, isOnBall, isOverBall, gameOver, nextLevel, textShown;
CP_Vector gPauseButtonPosition;
CP_Vector gResumeButtonPosition;
CP_Vector gRestartButtonPosition;
CP_Vector gMainMenuButtonPosition;
CP_Vector gLeftButtonPosition;
CP_Vector gRightButtonPosition;
CP_Vector gQuitButtonPosition;
CP_Vector buttonSize;
float timer;

CP_Color gButtonColor;
#define BUTTON_TYPE_PAUSE 0
#define BUTTON_TYPE_RESUME 1
#define BUTTON_TYPE_RESTART 2
#define BUTTON_TYPE_MAINMENU 3
#define BUTTON_TYPE_LEFT 4
#define BUTTON_TYPE_RIGHT 5
#define BUTTON_TYPE_QUIT 6
int gCurrentButtonType;
#define COLOR_GREEN CP_Color_Create(0, 255, 0, 255)
#define COLOR_WHITE CP_Color_Create(255, 255, 255, 255)

void HandleInput(void);
void Update(void);
void Render(void);
void RenderUI(void);
void HoverButton(void);
void DetectBall(CP_Vector mousePos);
GameObject* GetGO(void);

void Desmond_init(void)
{
	gButtonColor = COLOR_WHITE;

	CP_Settings_RectMode(CP_POSITION_CENTER);
	gPauseButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() - BUTTON_WIDTH * .5f, BUTTON_HEIGHT * .5f);
	gResumeButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .51f, 230.f);
	gRestartButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .51f, 330.f);
	gMainMenuButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .51f, 430.f);
	gLeftButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * (SceneManagerGetCurrentIndex() == Level_Three ? .5f : .30f), CP_System_GetWindowHeight() * .5f);
	gRightButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .70f, CP_System_GetWindowHeight() * .5f);
	gQuitButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .51f, 530.f);

	buttonSize = CP_Vector_Set(BUTTON_WIDTH, BUTTON_HEIGHT);

	gIsPaused = FALSE;
	textShown = TRUE;
	gameOver = 0;
	hitNo = 0;
	timer = 0;
	isOverBall = 0;
	nextLevel = 0;
	gameobjectList = (GameObject**)malloc(GAMEOBJECTSIZE * sizeof(GameObject*));
	for (int i = 0; i < GAMEOBJECTSIZE; ++i)
	{
		if (!gameobjectList)
			break;
		gameobjectList[i] = (GameObject*)malloc(sizeof(GameObject));
		GameObject_Init(gameobjectList[i]);
	}
	CP_Vector gameSize = CP_Vector_Set(480, 720);
	CP_Vector diff = CP_Vector_Scale(CP_Vector_Subtract(CP_Vector_Set((float)CP_System_GetWindowWidth(), (float)CP_System_GetWindowHeight()), gameSize), .5f);
	GameObject* go = GetGO();
	//Water
	go->renderType = GO_BOX;
	go->colorType = GO_WATER;
	go->pos = CP_Vector_Set(diff.x, 30);
	go->scale = CP_Vector_Set(250, 250); // size of the Water / 2
	go->dir = CP_Vector_Normalize(CP_Vector_Set(1, -1));
	go = GetGO();
	//Water
	go->renderType = GO_BOX;
	go->colorType = GO_WATER;
	go->pos = CP_Vector_Set(diff.x + gameSize.x, diff.y + gameSize.y);
	go->scale = CP_Vector_Set(250, 250); // size of the Water / 2
	go->dir = CP_Vector_Normalize(CP_Vector_Set(1, -1));

	//Sand
	go = GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_SAND;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .75f, diff.y + gameSize.y * .3f);
	go->scale = CP_Vector_Set(200, 50); // size of the Sand / 2
	go->dir = CP_Vector_Set(1, 0);

	//Sand
	go = GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_SAND;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .375f, diff.y + gameSize.y * .74f);
	go->scale = CP_Vector_Set(150, 50); // size of the Sand / 2
	go->dir = CP_Vector_Set(1, 0);

	//Sand
	go = GetGO();
	go->renderType = GO_CIRCLE;
	go->colorType = GO_SAND;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .55f, diff.y + gameSize.y * .74f);
	go->scale = CP_Vector_Set(30, 30); // size of the Sand / 2
	go->dir = CP_Vector_Set(1, 0);

	//Sand
	go = GetGO();
	go->renderType = GO_CIRCLE;
	go->colorType = GO_SAND;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .55f, diff.y + gameSize.y * .2f);
	go->scale = CP_Vector_Set(50, 50); // size of the Sand / 2
	go->dir = CP_Vector_Set(1, 0);

	//Wind
	go = GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WIND;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .35f, diff.y + gameSize.y * .625f);
	go->otherPos = CP_Vector_Set(-100, 0);
	go->scale = CP_Vector_Set(70, 120); // size of the Wind / 2
	go->dir = CP_Vector_Set(0, 1);

	//Wind
	go = GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WIND;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .13f, diff.y + gameSize.y * .65f);
	go->otherPos = CP_Vector_Set(0, 100);
	go->scale = CP_Vector_Set(120, 70); // size of the Wind / 2
	go->dir = CP_Vector_Set(0, 1);

	//Tunnel 1
	go = GetGO();
	go->renderType = GO_CIRCLE;
	go->colorType = GO_TUNNEL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .85f, diff.y + gameSize.y * .5f);
	go->otherPos = CP_Vector_Set(diff.x + gameSize.x * .85f, diff.y + gameSize.y * .6f);
	go->scale = CP_Vector_Set(10, 10); // size of the Tunnel / 2
	go->otherRadius = 10; // size of the Tunnel / 2
	go->dir = CP_Vector_Normalize(CP_Vector_Set(-1, 1));

	//Tunnel 2
	go = GetGO();
	go->renderType = GO_CIRCLE;
	go->colorType = GO_TUNNEL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .85f, diff.y + gameSize.y * .6f);
	go->otherPos = CP_Vector_Set(diff.x + gameSize.x * .85f, diff.y + gameSize.y * .5f);
	go->scale = CP_Vector_Set(10, 10); // size of the Tunnel / 2
	go->otherRadius = 10; // size of the Tunnel / 2
	go->dir = CP_Vector_Set(0, -1);

	//wall
	go = GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .55f, diff.y + gameSize.y * .4f);
	go->scale = CP_Vector_Set(200, 20);
	go->dir = CP_Vector_Normalize(CP_Vector_Set(0, -1));

	//wall
	go = GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .5f, diff.y + gameSize.y * .55f);
	go->scale = CP_Vector_Set(diff.x + gameSize.x, 30);
	go->dir = CP_Vector_Set(1, 0);

	//wall
	go = GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .85f, diff.y + gameSize.y * .15f);
	go->scale = CP_Vector_Set(200, 20);
	go->dir = CP_Vector_Normalize(CP_Vector_Set(-1, -1));

	//wall
	go = GetGO();
	go->renderType = GO_CIRCLE;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .45f, diff.y + gameSize.y * .85f);
	go->scale = CP_Vector_Set(20, 20);
	go->dir = CP_Vector_Set(1, 0);

	//wall
	go = GetGO();
	go->renderType = GO_CIRCLE;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .65f, diff.y + gameSize.y * .75f);
	go->scale = CP_Vector_Set(15, 15);
	go->dir = CP_Vector_Set(1, 0);

	//wall
	go = GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .35f, diff.y + gameSize.y * .69f);
	go->scale = CP_Vector_Set(20, 140);
	go->dir = CP_Vector_Set(0, 1);

	go = GetGO();
	//top
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .5f, diff.y + gameSize.y * .1f);
	go->scale = CP_Vector_Set(50, diff.x + gameSize.x);
	go->dir = CP_Vector_Set(0, -1);

	go = GetGO();
	//bottom
	//CP_Graphics_DrawRect(0, 390, 400, 10);
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x * .5f, diff.y + gameSize.y);
	go->scale = CP_Vector_Set(50, diff.x + gameSize.x);
	go->dir = CP_Vector_Set(0, 1);

	go = GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WATER;
	go->pos = CP_Vector_Set(diff.x * .5f, CP_System_GetWindowHeight() * .5f);
	go->scale = CP_Vector_Set(diff.x, diff.y + gameSize.y);
	go->dir = CP_Vector_Set(-1, 0);

	go = GetGO();
	//left
	//CP_Graphics_DrawRect(0, 60, 10, 350);
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(diff.x, diff.y + gameSize.y * .5f);
	go->scale = CP_Vector_Set(50, diff.y + gameSize.y);
	go->dir = CP_Vector_Set(1, 0);

	go = GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WATER;
	go->pos = CP_Vector_Set(diff.x * 1.5f + gameSize.x, CP_System_GetWindowHeight() * .5f);
	go->scale = CP_Vector_Set(diff.x, diff.y + gameSize.y);
	go->dir = CP_Vector_Set(-1, 0);

	go = GetGO();
	//right
	//CP_Graphics_DrawRect(390, 60, 10, 350);
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(diff.x + gameSize.x, diff.y + gameSize.y * .5f);
	go->scale = CP_Vector_Set(50, diff.y + gameSize.y);
	go->dir = CP_Vector_Set(-1, 0);

	goal = GetGO();
	goal->renderType = GO_CIRCLE;
	goal->colorType = GO_GOAL;
	goal->pos = CP_Vector_Set(diff.x + gameSize.x * .15f, diff.y + gameSize.y * .5f);
	goal->scale = CP_Vector_Set(10, 10);
	goal->dir = CP_Vector_Set(1, 0);

	player = GetGO();
	player->renderType = GO_CIRCLE;
	player->colorType = GO_PLAYER;
	player->otherPos = player->pos = CP_Vector_Set(diff.x + gameSize.x * .15f, diff.y + gameSize.y * .9f);
	player->scale = CP_Vector_Set(10, 10);
	player->vel = CP_Vector_Set(0, 0);
	player->dir = CP_Vector_Set(1, 0);
}

void Desmond_update(void)
{
	HandleInput();
	Update();
	Render();
	RenderUI();
	SceneManagerRenderBlack();
	HoverButton();
}

void Desmond_exit(void)
{
	for (int i = 0; i < GAMEOBJECTSIZE; ++i)
		free(gameobjectList[i]);

	free(gameobjectList);
	if (!nextLevel)
		Free_Sound();
}

void HandleInput()
{
	if (SceneManager_IsTransitioning())
		return;

	CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());

	if (gameOver)
	{
		if (CP_Input_MouseTriggered(MOUSE_BUTTON_1))
		{
			if (SceneManagerGetCurrentIndex() == Level_Three && Detect_button(mousePos, gLeftButtonPosition, buttonSize))
			{
				SceneManagerSetNextScene(MainMenuScene);
				nextLevel = 1;
			}
			else if (SceneManagerGetCurrentIndex() != Level_Three && Detect_button(mousePos, gRightButtonPosition, buttonSize))
			{
				if (goal->onSpecialTrigger)
				{
					SceneManagerSetNextScene((SceneManagerGetCurrentIndex() + 1) % Total_Scene); // next level
					nextLevel = 1;
				}
				else
				{
					nextLevel = 1;
					Desmond_exit();
					Desmond_init();
				}
				return;
			}
		}
		return;
	}

	if (CP_Input_KeyTriggered('P'))
	{
		if (gIsPaused == FALSE)
			gIsPaused = TRUE;
	}
	isOverBall = CP_Vector_Length(player->vel) == 0 && !isOnBall && Detect_ball(mousePos, player->pos, player->scale.x) && !gIsPaused;
	if (CP_Input_MouseTriggered(MOUSE_BUTTON_1))
	{
		if (gIsPaused == TRUE)
		{
			if (Detect_button(mousePos, gResumeButtonPosition, buttonSize))
			{
				gIsPaused = FALSE;
			}
			else if (Detect_button(mousePos, gRestartButtonPosition, buttonSize))
			{
				nextLevel = 1;
				Desmond_exit();
				Desmond_init();
				return;
			}
			else if (Detect_button(mousePos, gMainMenuButtonPosition, buttonSize))
			{
				SceneManagerSetNextScene(MainMenuScene);
				nextLevel = 1;
				return;
			}
			else if (Detect_button(mousePos, gQuitButtonPosition, buttonSize))
			{
				CP_Engine_Terminate();
			}
			return;
		}
		else if (Detect_button(mousePos, gPauseButtonPosition, buttonSize))
		{
			isOnBall = FALSE;
			gIsPaused = TRUE;
			return;
		}
		if (isOverBall)
		{
			isOnBall = TRUE;
		}
	}

	if (!gIsPaused && isOnBall)
	{
		DetectBall(mousePos);
	}
}

void HoverButton(void) {
	gButtonColor = COLOR_WHITE;
	CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());

	if (Detect_button(mousePos, gPauseButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_PAUSE;
	}
	else if (Detect_button(mousePos, gResumeButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_RESUME;

	}

	else if (Detect_button(mousePos, gRestartButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_RESTART;

	}

	else if (Detect_button(mousePos, gMainMenuButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_MAINMENU;

	}

	else if (Detect_button(mousePos, gLeftButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_LEFT;

	}

	else if (SceneManagerGetCurrentIndex() != Level_Three && Detect_button(mousePos, gRightButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_RIGHT;

	}

	else if (Detect_button(mousePos, gQuitButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_QUIT;

	}

}


void DetectBall(CP_Vector mousePos)
{
	//if mouse dragged, get new position to minus ball position for ball to move opposite direction
	CP_Vector updatedPos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());

	if (CP_Input_MouseReleased(MOUSE_BUTTON_LEFT))
	{
		//Ball will move to final position(current ball position + velocity)
		player->vel = CP_Vector_Subtract(player->pos, updatedPos);
		if (CP_Vector_DotProduct(player->vel, player->vel) > MAXBALLSPEED * MAXBALLSPEED)
			player->vel = CP_Vector_Scale(CP_Vector_Normalize(player->vel), MAXBALLSPEED);
		Play_SFX(SFX_HIT + player->onSpecialTrigger);
		isOnBall = FALSE;
		++hitNo;
		textShown = FALSE;
	}
}

void Update(void)
{
	SceneManagerUpdate();

	if (gIsPaused || gameOver)
		return;

	float dt = CP_System_GetDt();
	for (int i = 0; i < GAMEOBJECTSIZE; i++)
	{
		GameObject* go = gameobjectList[i];

		if (!go->enable)
			continue;

		if (go->colorType == GO_PLAYER)
		{
			if (go->inWater)
			{
				timer += dt;
				if (timer > 1)
					timer = 1;
				continue;
			}
			Update_Velocity(&(go->vel), go->onSpecialTrigger);
			if (CP_Vector_Length(player->vel) == 0)
				player->otherPos = player->pos;
			go->onSpecialTrigger = 0;
		}

		go->pos = CP_Vector_Add(go->pos, CP_Vector_Scale(go->vel, dt));


		for (int j = i; j < GAMEOBJECTSIZE; j++)
		{
			GameObject* go2 = gameobjectList[j];
			if (!go2->enable)
				continue;

			if (IsCollided(go, go2))
			{
				CollidedReaction(go, go2);
			}
		}
	}

	if ((!goal->onSpecialTrigger && hitNo < MAXHIT) || (hitNo >= MAXHIT && CP_Vector_Length(player->vel) != 0))
		return;
	gameOver = 1;
}

void RenderUI(void)
{
	CP_Settings_Stroke(CP_Color_Create(0, 0, 0, 255));
	CP_Settings_Fill(CP_Color_Create(50, 50, 50, 255));

	CP_Graphics_DrawRect(CP_System_GetWindowWidth() * .5f, (BUTTON_HEIGHT + 20) * .5f, (float)CP_System_GetWindowWidth(), BUTTON_HEIGHT + 20);
	/* This will set the 'fill' to white color */
	CP_Settings_Fill(COLOR_WHITE);

	CP_Graphics_DrawRect(gPauseButtonPosition.x, gPauseButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	if (gCurrentButtonType == BUTTON_TYPE_PAUSE)
	{
		CP_Settings_Fill(gButtonColor);
		CP_Graphics_DrawRect(gPauseButtonPosition.x, gPauseButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	}
	/* This will set the 'fill' with black color */
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));

	CP_Settings_TextSize(25.f);

	CP_Font_DrawText("Pause", gPauseButtonPosition.x - 28.f, gPauseButtonPosition.y);

	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));

	char text[100];
	sprintf_s(text, 100, "Hit : %d / %d", hitNo, MAXHIT);
	CP_Font_DrawText(text, gPauseButtonPosition.x - 270.f, gPauseButtonPosition.y + 10.f);

	sprintf_s(text, 100, "Level : %d", SceneManagerGetCurrentIndex() % Level_One + 1);
	CP_Font_DrawText(text, gPauseButtonPosition.x - 430.f, gPauseButtonPosition.y + 10.f);

	if (gIsPaused == TRUE)
	{
		/* This will set the 'fill' with black color */
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Settings_TextSize(80.f);
		CP_Font_DrawText("PAUSE", CP_System_GetWindowWidth() * .37f, 130.f);

		/* This will set the 'fill' to white color */
		CP_Settings_Fill(COLOR_WHITE);

		CP_Graphics_DrawRect(gResumeButtonPosition.x, gResumeButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		CP_Graphics_DrawRect(gRestartButtonPosition.x, gRestartButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		CP_Graphics_DrawRect(gMainMenuButtonPosition.x, gMainMenuButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		CP_Graphics_DrawRect(gQuitButtonPosition.x, gQuitButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);

		if (gCurrentButtonType == BUTTON_TYPE_RESUME)
		{
			CP_Settings_Fill(gButtonColor);
			CP_Graphics_DrawRect(gResumeButtonPosition.x, gResumeButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}
		else if (gCurrentButtonType == BUTTON_TYPE_RESTART)
		{
			CP_Settings_Fill(gButtonColor);
			CP_Graphics_DrawRect(gRestartButtonPosition.x, gRestartButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}

		else if (gCurrentButtonType == BUTTON_TYPE_MAINMENU)
		{
			CP_Settings_Fill(gButtonColor);
			CP_Graphics_DrawRect(gMainMenuButtonPosition.x, gMainMenuButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}

		else if (gCurrentButtonType == BUTTON_TYPE_QUIT)
		{
			CP_Settings_Fill(gButtonColor);
			CP_Graphics_DrawRect(gQuitButtonPosition.x, gQuitButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}

		/* This will set the 'fill' with black color */
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Settings_TextSize(25.f);
		CP_Font_DrawText("Resume Game", gResumeButtonPosition.x - 60.f, gResumeButtonPosition.y);
		CP_Font_DrawText("Restart Game", gRestartButtonPosition.x - 60.f, gRestartButtonPosition.y);
		CP_Font_DrawText("Return to Main Menu", gMainMenuButtonPosition.x - 93.f, gMainMenuButtonPosition.y);
		CP_Font_DrawText("Quit Game", gQuitButtonPosition.x - 43.f, gQuitButtonPosition.y);
		return;
	}
	CP_Settings_TextSize(50.f);
	if (textShown == TRUE) {

		CP_Font_DrawText("Drag the ball to start", CP_System_GetWindowWidth() / 4.f, CP_System_GetWindowHeight() / 1.9f);

	}

	if (!gameOver)
		return;

	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 150));
	CP_Graphics_DrawRect(CP_System_GetWindowWidth() * .5f, CP_System_GetWindowHeight() * .5f, (float)CP_System_GetWindowWidth(), (float)CP_System_GetWindowHeight());
	/* This will set the 'fill' with black color */
	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
	CP_Settings_TextSize(60.f);
	CP_Font_DrawText(goal->onSpecialTrigger ? "You Win" : "You Lose", CP_System_GetWindowWidth() * .45f - 58, CP_System_GetWindowHeight() * .35f);
	CP_Settings_TextSize(25.f);
	//win condition
	//check if ball is at the hole position and max hit is 12
		/* This will set the 'fill' to white color */
	CP_Settings_Fill(COLOR_WHITE);
	CP_Graphics_DrawRect(gLeftButtonPosition.x, gLeftButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	if (SceneManagerGetCurrentIndex() != Level_Three)
		CP_Graphics_DrawRect(gRightButtonPosition.x, gRightButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	if (gCurrentButtonType == BUTTON_TYPE_LEFT)
	{
		CP_Settings_Fill(gButtonColor);
		CP_Graphics_DrawRect(gLeftButtonPosition.x, gLeftButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	}
	else if (SceneManagerGetCurrentIndex() != Level_Three && gCurrentButtonType == BUTTON_TYPE_RIGHT)
	{
		CP_Settings_Fill(gButtonColor);
		CP_Graphics_DrawRect(gRightButtonPosition.x, gRightButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	}

	/* This will set the 'fill' with black color */
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Font_DrawText("Exit to Main Menu", gLeftButtonPosition.x - 82.f, gLeftButtonPosition.y);

	if (SceneManagerGetCurrentIndex() == Level_Three)
		return;
	/* This will set the 'fill' with black color */
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Font_DrawText(goal->onSpecialTrigger ? (SceneManagerGetCurrentIndex() == Total_Scene - 1 ? "Main Menu" : "Next Level") : "Restart Game", gRightButtonPosition.x - 50.f, gRightButtonPosition.y);
}

void Render(void)
{
	//draw
	/* This will fill the background with blue color */
	if (SceneManager_GetOverlayPercentage() < 1)
	{
		CP_Graphics_ClearBackground(CP_Color_Create(0, 255, 0, 255));


		for (int i = 0; i < GAMEOBJECTSIZE; i++)
		{
			GameObject* go = gameobjectList[i];
			GameObjectColorType colorType = go->colorType;
			if (!go->enable)
				continue;
			CP_Color color;
			CP_Vector scale = go->scale, pos = go->pos;
			switch (colorType)
			{
			case GO_PLAYER:
				CP_Settings_Stroke(CP_Color_Create(255 * isOverBall, 255 * isOverBall, 0, 255));
				CP_Settings_StrokeWeight(2);
				CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
				if (go->inWater)
				{
					pos = EaseInOutQuad(go->pos, go->otherPos, timer);
					if (timer >= 1)
					{
						go->inWater = 0;
						timer = 0;
						go->pos = go->otherPos;
					}
				}
				break;
			case GO_WALL:
				CP_Settings_Stroke(CP_Color_Create(0, 0, 0, 255));
				CP_Settings_StrokeWeight(3);
				CP_Settings_Fill(CP_Color_Create(139, 69, 19, 255));
				scale.x -= 3;
				scale.y -= 3;
				break;
			case GO_WATER:
				color = CP_Color_Create(0, 0, 255, 255);
				CP_Settings_Stroke(color);
				CP_Settings_StrokeWeight(1);
				CP_Settings_Fill(color);
				scale.x += 10;
				scale.y += 10;
				break;
			case GO_SAND:
				color = CP_Color_Create(226, 202, 118, 255);
				CP_Settings_Stroke(color);
				CP_Settings_StrokeWeight(1);
				CP_Settings_Fill(color);
				scale.x += 10;
				scale.y += 10;
				break;
			case GO_WIND:
				color = CP_Color_Create(0, 128, 128, 150);
				CP_Settings_Stroke(color);
				CP_Settings_StrokeWeight(1);
				CP_Settings_Fill(color);
				scale.x += 10;
				scale.y += 10;
				break;
			case GO_TUNNEL:
				color = CP_Color_Create(60, 60, 60, 255);
				CP_Settings_Stroke(color);
				CP_Settings_StrokeWeight(1);
				CP_Settings_Fill(color);
				scale.x += 10;
				scale.y += 10;
				break;
			case GO_GOAL:
				color = CP_Color_Create(10, 10, 10, 255);
				CP_Settings_Stroke(color);
				CP_Settings_StrokeWeight(1);
				CP_Settings_Fill(color);
				scale.x += 10;
				scale.y += 10;
				break;
			}

			switch (go->renderType)
			{
			case GO_CIRCLE:
				CP_Graphics_DrawCircle(pos.x, pos.y, go->scale.x * 2);
				break;
			case GO_BOX:
				CP_Graphics_DrawRectAdvanced(pos.x, pos.y, scale.x, scale.y, CP_Math_Degrees(atan2f(go->dir.y, go->dir.x)), 0);
				break;
			}
		}

		CP_Settings_Stroke(CP_Color_Create(0, 0, 0, 255));
		CP_Settings_StrokeWeight(1);
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		CP_Graphics_DrawRect(goal->pos.x, goal->pos.y - 25, 7, 50);
		CP_Settings_Fill(CP_Color_Create(255, 0, 0, 255));
		CP_Graphics_DrawTriangle(goal->pos.x + 3.5f, goal->pos.y - 50, goal->pos.x + 3.5f, goal->pos.y - 25, goal->pos.x + 25, goal->pos.y - 37.5f);

		if (isOnBall == TRUE)
		{
			CP_Settings_Stroke(CP_Color_Create(0, 0, 0, 255));
			CP_Vector mouse = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
			CP_Vector relative = CP_Vector_Subtract(mouse, player->pos);
			if (CP_Vector_DotProduct(relative, relative) > (MAXBALLSPEED - 100) * (MAXBALLSPEED - 100))
				relative = CP_Vector_Scale(CP_Vector_Normalize(relative), MAXBALLSPEED - 100);
			CP_Settings_StrokeWeight(2);
			CP_Graphics_DrawLine(player->pos.x - relative.x, player->pos.y - relative.y, player->pos.x, player->pos.y);
		}

	}
}

GameObject* GetGO()
{
	GameObject* go;
	for (int i = 0; i < GAMEOBJECTSIZE; i++)
	{
		go = gameobjectList[i];
		if (go->enable)
			continue;

		go->enable = 1;
		break;
	}

	return go;
}