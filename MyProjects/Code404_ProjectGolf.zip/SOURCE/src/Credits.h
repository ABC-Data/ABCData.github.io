 /*---------------------------------------------------------
  * file:	Credits.h
  * author:	Sarah Tan Yu Hong
  * email:	sarahyuhong.t@digipen.edu
  *
  * brief:	This file declare functions that help to create the game credits.
  *
  * documentation link:
  * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
  *
  * Copyright @ 2020 DigiPen, All rights reserved.
  * ---------------------------------------------------------*/

#pragma once

void Credits_init(void);
void Credits_update(void);
void Credits_exit(void);
void Credits_HandleInput(void);
void Credits_Update(void);
void Credits_Render(void);
void Credits_HoverButton(void);
