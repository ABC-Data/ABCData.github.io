﻿/*---------------------------------------------------------
 * file:	Desmond_level.h
 * author:	Desmond peh han yong
 * email:	desmondhanyong.peh@digipen.edu
 *
 * brief:	Declaration of Scene Functions
 *
 * Copyright @ 2021 DigiPen, All rights reserved.
 *---------------------------------------------------------*/
#pragma once
void Desmond_init(void);
void Desmond_update(void);
void Desmond_exit(void);