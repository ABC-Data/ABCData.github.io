﻿/*---------------------------------------------------------
 * file:	SplashScene.h
 * author:	Desmond peh han yong
 * email:	desmondhanyong.peh@digipen.edu
 *
 * brief:	Declaration of Scene Functions
 *
 * Copyright @ 2021 DigiPen, All rights reserved.
 *---------------------------------------------------------*/
#pragma once

void SplashScene_init(void);
void SplashScene_update(void);
void SplashScene_exit(void);