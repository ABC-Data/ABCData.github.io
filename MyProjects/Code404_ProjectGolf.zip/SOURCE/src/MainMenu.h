 /*---------------------------------------------------------
  * file:	MainMenu.h
  * author:	Sarah Tan Yu Hong
  * email:	sarahyuhong.t@digipen.edu
  *
  * brief:	This file declare functions that help to create the main menu for the golf game and 
            perform tasks like start game and quit game.
  *
  * documentation link:
  * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
  *
  * Copyright @ 2020 DigiPen, All rights reserved.
  * ---------------------------------------------------------*/

#pragma once

#include "GameObject.h"
void MainMenu_init(void);
void MainMenu_update(void);
void MainMenu_exit(void);
void MainMenu_HandleInput(void);
void MainMenu_HoverButton(void);
void MainMenu_Update(void);
void MainMenu_Render(void);

