/*---------------------------------------------------------
 * file:	Physics.h
 * author:	Warren Ang Jun Xuan
 * email:	a.warrenjunxuan@digipen.edu
 *
 * brief:	Calculation of ball acceleration.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/

#include "cprocessing.h"
#include <math.h>
#define DECEL -50.f //deceleration
#define FRICTION -100.f //friction, if on sand, velocity decreases further

void Update_Velocity(CP_Vector* ballVel, int onSand);
