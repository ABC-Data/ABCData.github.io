/*---------------------------------------------------------
 * file:	mouseinput.h
 * author:	Warren Ang Jun Xuan
 * email:	a.warrenjunxuan@digipen.edu
 *
 * brief:	Detection of mouse click on ball/button.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/

#include "cprocessing.h"
#include <math.h>

int Detect_ball(CP_Vector mousePos, CP_Vector ballPos, float ballSize);
int Detect_button(CP_Vector mouse, CP_Vector buttonPos, CP_Vector buttonSize);
