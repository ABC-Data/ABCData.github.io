 /*---------------------------------------------------------
  * file:	Sarah_Level.h
  * author:	Sarah Tan Yu Hong
  * email:	sarahyuhong.t@digipen.edu
  *
  * brief:	This file declare functions that help to create the level 2 of the golf game and perform 
            tasks like resume, start, quit game when the game is paused.
  *
  * documentation link:
  * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
  *
  * Copyright @ 2020 DigiPen, All rights reserved.
  * ---------------------------------------------------------*/

#pragma once
void Sarah_init(void);
void Sarah_update(void);
void Sarah_exit(void);
