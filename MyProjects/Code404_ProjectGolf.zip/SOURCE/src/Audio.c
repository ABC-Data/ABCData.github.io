﻿/*---------------------------------------------------------
 * file:	Audio.c
 * author:	Desmond peh han yong
 * email:	desmondhanyong.peh@digipen.edu
 *
 * brief:	Defination of Audios Functions
 *
 * Copyright @ 2021 DigiPen, All rights reserved.
 *---------------------------------------------------------*/
#include "Audio.h"
int init = 0;
void Audio_Init(void)
{
	if (init) return;
	init = 1;
	BGM = CP_Sound_Load("./Assets/DO IT - Sports MSCSPR1_29.wav");
	SFX[SFX_GOAL] = CP_Sound_Load("./Assets/GOLF_GEN-HDF-13025.wav");
	SFX[SFX_WATER] = CP_Sound_Load("./Assets/GOLF_GEN-HDF-13032.wav");
	SFX[SFX_TUNNEL] = CP_Sound_Load("./Assets/TYPEWRITER-MANUAL_GEN-HDF-25098.wav");
	SFX[SFX_HIT] = CP_Sound_Load("./Assets/GOLF_GEN-HDF-13040.wav");
	SFX[SFX_HIT_SAND] = CP_Sound_Load("./Assets/GOLF_GEN-HDF-13094.wav");
	SFX[SFX_HIT_WALL] = CP_Sound_Load("./Assets/GOLF_GEN-HDF-13051.wav");
	CP_Sound_PlayAdvanced(BGM, CP_Sound_GetGroupVolume(CP_SOUND_GROUP_MUSIC), CP_Sound_GetGroupPitch(CP_SOUND_GROUP_MUSIC), TRUE, CP_SOUND_GROUP_MUSIC);
}

void Play_SFX(SFX_Type type)
{
	CP_Sound_PlayAdvanced(SFX[type], CP_Sound_GetGroupVolume(CP_SOUND_GROUP_SFX), CP_Sound_GetGroupPitch(CP_SOUND_GROUP_SFX), FALSE, CP_SOUND_GROUP_SFX);
}

void Free_Sound(void)
{
	CP_Sound_Free(&BGM);
	for (int i = 0; i < SFX_LAST; i++)
		CP_Sound_Free(&SFX[i]);

}