/*---------------------------------------------------------
 * file:	MainMenu.c
 * author:	Sarah Tan Yu Hong
 * email:	sarahyuhong.t@digipen.edu
 *
 * brief:	This file contain functions that help to create the main menu for the golf game and
			perform tasks like start game and quit game.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/


#include <stdio.h>
#include <stdlib.h> 
#include "cprocessing.h"
#include "mouseinput.h"
#include "MainMenu.h"
#include "Options.h"
#include "Audio.h"
#include "SceneManager.h"

#define BUTTON_WIDTH 200.f
#define BUTTON_HEIGHT 60.f

CP_Vector gStartButtonPosition;
CP_Vector gOptionButtonPosition;
CP_Vector gHowToPlayButtonPosition;
CP_Vector gCreditButtonPosition;
CP_Vector gExitButtonPosition;
CP_Vector buttonSize;
CP_Color gButtonColor;
#define BUTTON_TYPE_START 0
#define BUTTON_TYPE_OPTION 1
#define BUTTON_TYPE_HOWTOPLAY 2
#define BUTTON_TYPE_CREDIT 3
#define BUTTON_TYPE_EXIT 4
int gCurrentButtonType;
#define COLOR_GREEN CP_Color_Create(0, 255, 0, 255)
#define COLOR_WHITE CP_Color_Create(255, 255, 255, 255)
CP_Image gameName, logo;

typedef struct _Particle
{
	CP_Vector pos;
	CP_Vector vel;
	CP_Color* color;
} Particle;

const float EPSILON4 = 0.0000001f;

Particle particles[30];
int numParticles4 = 30, nextLevel;

float circleProximityDistance4 = 100.0f;

CP_Color color;

CP_Color randomColors4[] = {
	{ 128, 0,   0,   255 },
	{ 128, 128, 0,   255 },
	{ 0,   128, 0,   255 },
	{ 0,   128, 128, 255 },
	{ 0,   0,   128, 255 },
	{ 128, 0,   128, 255 } };

void ParticleCreate4(Particle* part) {

	part->pos.x = CP_Random_RangeFloat(0, (float)CP_System_GetWindowWidth());
	part->pos.y = CP_Random_RangeFloat(0, (float)CP_System_GetWindowHeight());
	part->vel.x = CP_Random_RangeFloat(-150, 150);
	part->vel.y = CP_Random_RangeFloat(-150, 150);
	part->color = &randomColors4[CP_Random_RangeInt(0, 5)];
}


void ParticleUpdate4(Particle* part)
{

	// move particle based on velocity and correct for wall collisions
	float time = CP_System_GetDt();
	float timeX = time;
	float timeY = time;

	while (time > EPSILON4)
	{
		int collisionX = FALSE;
		int collisionY = FALSE;

		float newPosX = part->pos.x + part->vel.x * time;
		float newPosY = part->pos.y + part->vel.y * time;
		float newTime = time;

		// check wall collisions X and Y
		if (newPosX <= 0)
		{
			timeX = part->pos.x / (part->pos.x - newPosX) * time;
			collisionX = TRUE;
		}
		else if (newPosX >= CP_System_GetWindowWidth())
		{
			timeX = (CP_System_GetWindowWidth() - part->pos.x) / (newPosX - part->pos.x) * time;
			collisionX = TRUE;
		}

		if (newPosY <= 0)
		{
			timeY = part->pos.y / (part->pos.y - newPosY) * time;
			collisionY = TRUE;
		}
		else if (newPosY >= CP_System_GetWindowHeight())
		{
			timeY = (CP_System_GetWindowHeight() - part->pos.y) / (newPosY - part->pos.y) * time;
			collisionY = TRUE;
		}

		// resolve collisions
		if ((collisionX == TRUE) || (collisionY == TRUE))
		{

			// take the nearest time
			if (timeX < timeY)
			{
				newTime = timeX;
			}
			else
			{
				newTime = timeY;
			}

			// move the particle
			part->pos.x += part->vel.x * newTime;
			part->pos.y += part->vel.y * newTime;

			// flip velocity vectors to reflect off walls
			if ((collisionX == TRUE) && (collisionY == FALSE))
			{
				part->vel.x *= -1;
			}
			else if ((collisionX == FALSE) && (collisionY == TRUE))
			{
				part->vel.y *= -1;
			}
			else
			{	// they must both be colliding for this condition to occur
				if (timeX < timeY)
				{
					part->vel.x *= -1;
				}
				else if (timeX > timeY)
				{
					part->vel.y *= -1;
				}
				else
				{	// they must be colliding at the same time (ie. a corner)
					part->vel.x *= -1;
					part->vel.y *= -1;
				}
			}

			// decrease time and iterate
			time -= newTime;
		}
		else
		{
			// no collision
			part->pos.x = newPosX;
			part->pos.y = newPosY;
			time = 0;
		}
	}
}


void MainMenu_init(void)
{
	for (int i = 0; i < numParticles4; ++i) {
		ParticleCreate4(&particles[i]);
	}
	gameName = CP_Image_Load("./Assets/gameName.png");
	logo = CP_Image_Load("./Assets/logo.png");

	gButtonColor = COLOR_WHITE;
	nextLevel = 0;
	CP_Settings_RectMode(CP_POSITION_CENTER);
	gStartButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .5f, 250.f);
	gOptionButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .5f, 350.f);
	gHowToPlayButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .5f, 450.f);
	gCreditButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .5f, 550.f);
	gExitButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .5f, 650.f);
	buttonSize = CP_Vector_Set(BUTTON_WIDTH, BUTTON_HEIGHT);
}

void MainMenu_update(void)
{
	MainMenu_HandleInput();
	MainMenu_HoverButton();
	MainMenu_Update();
	MainMenu_Render();
}

void MainMenu_exit(void)
{
	CP_Image_Free(&gameName);
	CP_Image_Free(&logo);
	if (!nextLevel)
		Free_Sound();
}

void MainMenu_HandleInput()
{
	if (SceneManager_IsTransitioning())
		return;

	CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
	if (CP_Input_MouseTriggered(MOUSE_BUTTON_1))
	{
		//Play
		if (Detect_button(mousePos, gStartButtonPosition, buttonSize))
		{
			SceneManagerSetNextScene(Level_One);
			nextLevel = 1;
			return;
		}
		//Options
		else if (Detect_button(mousePos, gOptionButtonPosition, buttonSize))
		{
			SceneManagerSetNextScene(Option_Scene);
			nextLevel = 1;
			return;
		}
		//How to play
		else if (Detect_button(mousePos, gHowToPlayButtonPosition, buttonSize))
		{
			SceneManagerSetNextScene(HowToPlay_Scene);
			nextLevel = 1;
			return;
		}
		//Credit
		else if (Detect_button(mousePos, gCreditButtonPosition, buttonSize))
		{
			SceneManagerSetNextScene(Credit_Scene);
			nextLevel = 1;
			return;
		}
		//Exit
		else if (Detect_button(mousePos, gExitButtonPosition, buttonSize))
		{
			CP_Engine_Terminate();
		}
	}
}

void MainMenu_HoverButton(void) {
	gButtonColor = COLOR_WHITE;
	CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
	//Play
	if (Detect_button(mousePos, gStartButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_START;

	}
	//Options
	else if (Detect_button(mousePos, gOptionButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_OPTION;
	}
	//How to play
	else if (Detect_button(mousePos, gHowToPlayButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_HOWTOPLAY;

	}
	//Credit
	else if (Detect_button(mousePos, gCreditButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_CREDIT;

	}
	//Exit
	else if (Detect_button(mousePos, gExitButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_EXIT;

	}
}

void MainMenu_Update(void)
{

	SceneManagerUpdate();
}

void MainMenu_Render(void)
{
	if (SceneManager_GetOverlayPercentage() < 1.f)
	{
		CP_Settings_BlendMode(CP_BLEND_ALPHA);
		CP_Graphics_ClearBackground(CP_Color_Create(0, 0, 0, 255));

		for (int i = 0; i < numParticles4; ++i)
		{
			ParticleUpdate4(&particles[i]);
		}

		CP_Settings_StrokeWeight(3);

		for (int i = 0; i < numParticles4; ++i)
		{

			for (int j = i + 1; j < numParticles4; ++j)
			{
				float distX = (float)fabsf(particles[i].pos.x - particles[j].pos.x);
				float distY = (float)fabsf(particles[i].pos.y - particles[j].pos.y);
				if (distX < circleProximityDistance4 && distY < circleProximityDistance4)
				{
					color.r = particles[i].color->r + particles[j].color->r;
					color.g = particles[i].color->g + particles[j].color->g;
					color.b = particles[i].color->b + particles[j].color->b;
					color.a = (unsigned char)(255.0f * min(1.0f, (circleProximityDistance4 - max(distX, distY)) / (circleProximityDistance4 * 0.3f)));
					CP_Settings_Stroke(color);
					CP_Graphics_DrawCircle(particles[i].pos.x, particles[i].pos.y, 20);
				}
			}
		}
		CP_Settings_NoStroke();

		CP_Settings_Stroke(CP_Color_Create(0, 0, 0, 255));

		/* This will set the 'fill' with white color */
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));

		// Load an image from the assets folder 
		CP_Image_Draw(gameName, CP_System_GetWindowWidth() / 2.3f, CP_System_GetWindowHeight() / 8.0f, 500, 200, 255);
		CP_Image_Draw(logo, 620, CP_System_GetWindowHeight() / 6.0f, 150, 130, 255);

		//CP_Settings_TextSize(60.0f);

		//CP_Font_DrawText("Project Golf", CP_System_GetWindowWidth() * .32f, CP_System_GetWindowHeight() * .15f);
		CP_Settings_Fill(COLOR_WHITE);

		CP_Graphics_DrawRect(gStartButtonPosition.x, gStartButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		CP_Graphics_DrawRect(gOptionButtonPosition.x, gOptionButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		CP_Graphics_DrawRect(gHowToPlayButtonPosition.x, gHowToPlayButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		CP_Graphics_DrawRect(gCreditButtonPosition.x, gCreditButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		CP_Graphics_DrawRect(gExitButtonPosition.x, gExitButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);

		if (gCurrentButtonType == BUTTON_TYPE_START)
		{
			CP_Settings_Fill(gButtonColor);

			CP_Graphics_DrawRect(gStartButtonPosition.x, gStartButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}

		else if (gCurrentButtonType == BUTTON_TYPE_OPTION)
		{
			CP_Settings_Fill(gButtonColor);

			CP_Graphics_DrawRect(gOptionButtonPosition.x, gOptionButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}

		else if (gCurrentButtonType == BUTTON_TYPE_HOWTOPLAY)
		{
			CP_Settings_Fill(gButtonColor);

			CP_Graphics_DrawRect(gHowToPlayButtonPosition.x, gHowToPlayButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}

		else if (gCurrentButtonType == BUTTON_TYPE_CREDIT)
		{
			CP_Settings_Fill(gButtonColor);

			CP_Graphics_DrawRect(gCreditButtonPosition.x, gCreditButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}

		else if (gCurrentButtonType == BUTTON_TYPE_EXIT)
		{
			CP_Settings_Fill(gButtonColor);

			CP_Graphics_DrawRect(gExitButtonPosition.x, gExitButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}
		/* This will set the 'fill' with black color */
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Settings_TextSize(25.0f);

		CP_Font_DrawText("Start Game", gStartButtonPosition.x - 47.f, gStartButtonPosition.y);

		CP_Font_DrawText("Options", gOptionButtonPosition.x - 37.f, gOptionButtonPosition.y);

		CP_Font_DrawText("How to Play", gHowToPlayButtonPosition.x - 50.f, gHowToPlayButtonPosition.y);

		CP_Font_DrawText("Credits", gCreditButtonPosition.x - 35.f, gCreditButtonPosition.y);

		CP_Font_DrawText("Quit Game", gExitButtonPosition.x - 45.f, gExitButtonPosition.y);
	}
	SceneManagerRenderBlack();
}

