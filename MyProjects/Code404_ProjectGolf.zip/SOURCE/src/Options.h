/*---------------------------------------------------------
 * file:	Options.h
 * author:	Warren Ang Jun Xuan
 *			Desmond Peh Han Yong
 * email:	a.warrenjunxuan@digipen.edu
 *			desmondhanyong.peh@digipen.edu
 *
 * brief:	Options for music and sfx volume control.(Warren)
 *			Implementation of Audio.c with volume control.(Desmond)
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/

#include "cprocessing.h"
#define width 300.f
#define height 300.f
int master_vol, music_vol, sfx_vol;

void Options_init(void);
void Options_update(void);
void Options_exit(void);
void option_tab();
int master_volume(float audio_x, float audio_y, int volume);
int music(float audio_x, float audio_y, int volume);
int sfx(float audio_x, float audio_y, int volume);