/*---------------------------------------------------------
 * file:	Sarah_Level.c
 * author:	Sarah Tan Yu Hong
 * email:	sarahyuhong.t@digipen.edu
 *
 * brief:	This file contain functions that help to create the level 2 of the golf game and perform
			tasks like resume, start, quit game when the game is paused.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h> 
#include "cprocessing.h"
#include "mouseinput.h"
#include "Sarah_Level.h"
#include "SceneManager.h"
#include "Physics.h"
#include "GameObject.h"
#include "Audio.h"

#define GAMEOBJECTSIZE 40
#define MAXBALLSPEED 300.f
#define MAXHIT 12
#define TRUE 1
#define FALSE 0
#define BUTTON_WIDTH 230.f
#define BUTTON_HEIGHT 60.f
GameObject** gameobjectList;
GameObject* player;
GameObject* goal;
int gIsPaused, hitNo, isOnBall, isOverBall, gameOver, nextLevel;
CP_Vector gPauseButtonPosition;
CP_Vector gResumeButtonPosition;
CP_Vector gRestartButtonPosition;
CP_Vector gMainMenuButtonPosition;
CP_Vector gLeftButtonPosition;
CP_Vector gRightButtonPosition;
CP_Vector gQuitButtonPosition;
CP_Vector buttonSize;
float timer;

CP_Color gButtonColor;
#define BUTTON_TYPE_PAUSE 0
#define BUTTON_TYPE_RESUME 1
#define BUTTON_TYPE_RESTART 2
#define BUTTON_TYPE_MAINMENU 3
#define BUTTON_TYPE_LEFT 4
#define BUTTON_TYPE_RIGHT 5
#define BUTTON_TYPE_QUIT 6
int gCurrentButtonType;
#define COLOR_GREEN CP_Color_Create(0, 255, 0, 255)
#define COLOR_WHITE CP_Color_Create(255, 255, 255, 255)

void Sarah_HandleInput(void);
void Sarah_Update(void);
void Sarah_Render(void);
void Sarah_RenderUI(void);
void Sarah_HoverButton(void);
void Sarah_DetectBall(CP_Vector mousePos);
GameObject* Sarah_GetGO(void);

void Sarah_init(void)
{
	gButtonColor = COLOR_WHITE;

	CP_Settings_RectMode(CP_POSITION_CENTER);
	gPauseButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() - BUTTON_WIDTH * .5f, BUTTON_HEIGHT * .5f);
	gResumeButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .51f, 230.f);
	gRestartButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .51f, 330.f);
	gMainMenuButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .51f, 430.f);
	gLeftButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * (SceneManagerGetCurrentIndex() == Level_Three ? .5f : .30f), CP_System_GetWindowHeight() * .5f);
	gRightButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .70f, CP_System_GetWindowHeight() * .5f);
	gQuitButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .51f, 530.f);

	buttonSize = CP_Vector_Set(BUTTON_WIDTH, BUTTON_HEIGHT);
	gameOver = 0;
	hitNo = 0;
	timer = 0;
	nextLevel = 0;
	isOverBall = 0;
	gIsPaused = FALSE;
	gameobjectList = (GameObject**)malloc(GAMEOBJECTSIZE * sizeof(GameObject*));
	for (int i = 0; i < GAMEOBJECTSIZE; ++i)
	{
		if (!gameobjectList)
			break;
		gameobjectList[i] = (GameObject*)malloc(sizeof(GameObject));
		GameObject_Init(gameobjectList[i]);
	}

	GameObject* go = Sarah_GetGO();

	//Water
	go = Sarah_GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WATER;
	go->pos = CP_Vector_Set(0, CP_System_GetWindowHeight() * .5f);
	go->scale = CP_Vector_Set(30, 450); // size of the Water / 2
	go->dir = CP_Vector_Set(0, 1);

	//Water
	go = Sarah_GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WATER;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .97f, CP_System_GetWindowHeight() * .75f);
	go->scale = CP_Vector_Set(55, 413); // size of the Water / 
	go->dir = CP_Vector_Set(1, 0);

	//Sand
	go = Sarah_GetGO();
	go->renderType = GO_CIRCLE;
	go->colorType = GO_SAND;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .20f, CP_System_GetWindowHeight() * .70f);
	go->scale = CP_Vector_Set(60, 60);
	go->dir = CP_Vector_Set(0, 1);

	//Sand
	go = Sarah_GetGO();
	go->renderType = GO_CIRCLE;
	go->colorType = GO_SAND;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .65f, CP_System_GetWindowHeight() * .60f);
	go->scale = CP_Vector_Set(60, 60);
	go->dir = CP_Vector_Set(0, 1);


	//Wind
	go = Sarah_GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WIND;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .75f, CP_System_GetWindowHeight() * .80f);
	go->otherPos = CP_Vector_Set(0, 2000);
	go->scale = CP_Vector_Set(30, 50); // size of the Wind / 2
	go->dir = CP_Vector_Set(0, 1);

	//Wind
	go = Sarah_GetGO();
	go->renderType = GO_BOX;
	go->colorType = GO_WIND;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .30f, CP_System_GetWindowHeight() * .40f);
	go->otherPos = CP_Vector_Set(0, 2000);
	go->scale = CP_Vector_Set(30, 50); // size of the Wind / 2
	go->dir = CP_Vector_Set(0, 1);

	//Tunnel
	go = Sarah_GetGO();
	go->renderType = GO_CIRCLE;
	go->colorType = GO_TUNNEL;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .2f, CP_System_GetWindowHeight() * .80f);
	go->otherPos = CP_Vector_Set(CP_System_GetWindowWidth() * .88f, CP_System_GetWindowHeight() * .60f);
	go->scale = CP_Vector_Set(10, 10); // size of the Tunnel / 2
	go->otherRadius = 10; // size of the Tunnel / 2
	go->dir = CP_Vector_Set(0, 1);

	//Tunnel
	go = Sarah_GetGO();
	go->renderType = GO_CIRCLE;
	go->colorType = GO_TUNNEL;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .88f, CP_System_GetWindowHeight() * .60f);
	go->otherPos = CP_Vector_Set(CP_System_GetWindowWidth() * .2f, CP_System_GetWindowHeight() * .80f);
	go->scale = CP_Vector_Set(10, 10); // size of the Tunnel / 2
	go->otherRadius = 10; // size of the Tunnel / 2
	go->dir = CP_Vector_Set(0, 1);


	go = Sarah_GetGO();
	//Wall
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set((float)CP_System_GetWindowWidth() * .60f, CP_System_GetWindowHeight() * .15f);
	go->scale = CP_Vector_Set(100, 20);
	go->dir = CP_Vector_Set(0, 1);

	go = Sarah_GetGO();
	//Wall
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set((float)CP_System_GetWindowWidth() * .40f, CP_System_GetWindowHeight() * .36f);
	go->scale = CP_Vector_Set(100, 20);
	go->dir = CP_Vector_Set(0, 1);


	go = Sarah_GetGO();
	//Wall
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .4f, (float)CP_System_GetWindowHeight());
	go->scale = CP_Vector_Set(1590, 20);
	go->dir = CP_Vector_Normalize(CP_Vector_Set(1, -1));



	go = Sarah_GetGO();
	//Wall
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .5f, CP_System_GetWindowHeight() * .30f);
	go->scale = CP_Vector_Set(20, 550);
	go->dir = CP_Vector_Set(0, 1);



	go = Sarah_GetGO();
	//top
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .5f, CP_System_GetWindowHeight() * .09f);
	go->scale = CP_Vector_Set(20, 720);
	go->dir = CP_Vector_Set(0, 1);

	go = Sarah_GetGO();
	//bottom
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .5f, (float)CP_System_GetWindowHeight());
	go->scale = CP_Vector_Set((float)CP_System_GetWindowWidth(), 50);
	go->dir = CP_Vector_Set(1, 0);


	go = Sarah_GetGO();
	//left
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set(0, CP_System_GetWindowHeight() * .5f);
	go->scale = CP_Vector_Set(750, 50);
	go->dir = CP_Vector_Set(0, -1);

	go = Sarah_GetGO();
	//right
	go->renderType = GO_BOX;
	go->colorType = GO_WALL;
	go->pos = CP_Vector_Set((float)CP_System_GetWindowWidth(), CP_System_GetWindowHeight() * .5f);
	go->scale = CP_Vector_Set(750, 50);
	go->dir = CP_Vector_Set(0, 1);


	goal = Sarah_GetGO();
	goal->renderType = GO_CIRCLE;
	goal->colorType = GO_GOAL;
	goal->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .20f, CP_System_GetWindowHeight() * .20f);
	goal->scale = CP_Vector_Set(10, 10);
	goal->dir = CP_Vector_Set(1, 0);

	player = Sarah_GetGO();
	player->renderType = GO_CIRCLE;
	player->colorType = GO_PLAYER;
	player->otherPos = player->pos = CP_Vector_Set(CP_System_GetWindowWidth() * .55f, CP_System_GetWindowHeight() * .92f);
	player->scale = CP_Vector_Set(10, 10);
	player->vel = CP_Vector_Set(0, 0);
	player->dir = CP_Vector_Set(1, 0);
}


void Sarah_update(void)
{
	Sarah_HandleInput();
	Sarah_Update();
	Sarah_Render();
	Sarah_RenderUI();
	SceneManagerRenderBlack();
	Sarah_HoverButton();
}

void Sarah_exit(void)
{
	for (int i = 0; i < GAMEOBJECTSIZE; ++i)
		free(gameobjectList[i]);

	free(gameobjectList);
	if (!nextLevel)
		Free_Sound();
}


void Sarah_HandleInput()
{
	if (SceneManager_IsTransitioning())
		return;

	CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());

	if (gameOver)
	{
		if (CP_Input_MouseTriggered(MOUSE_BUTTON_1))
		{
			if (SceneManagerGetCurrentIndex() == Level_Three && Detect_button(mousePos, gLeftButtonPosition, buttonSize))
			{
				SceneManagerSetNextScene(MainMenuScene);
				nextLevel = 1;
			}
			else if (Detect_button(mousePos, gRightButtonPosition, buttonSize))
			{
				if (goal->onSpecialTrigger)
				{
					SceneManagerSetNextScene((SceneManagerGetCurrentIndex() + 1) % Total_Scene); // next level
					nextLevel = 1;
				}
				else
				{
					nextLevel = 1;
					Sarah_exit();
					Sarah_init();
				}
				return;
			}
		}
		return;
	}

	if (CP_Input_KeyTriggered('P'))
	{
		if (gIsPaused == FALSE)
			gIsPaused = TRUE;
	}
	isOverBall = CP_Vector_Length(player->vel) == 0 && !isOnBall && Detect_ball(mousePos, player->pos, player->scale.x) && !gIsPaused;
	if (CP_Input_MouseTriggered(MOUSE_BUTTON_1))
	{
		if (gIsPaused == TRUE)
		{
			if (Detect_button(mousePos, gResumeButtonPosition, buttonSize))
			{
				gIsPaused = FALSE;
			}
			else if (Detect_button(mousePos, gRestartButtonPosition, buttonSize))
			{
				nextLevel = 1;
				Sarah_exit();
				Sarah_init();
				return;
			}
			else if (Detect_button(mousePos, gMainMenuButtonPosition, buttonSize))
			{
				SceneManagerSetNextScene(MainMenuScene);
				nextLevel = 1;
				return;
			}
			else if (Detect_button(mousePos, gQuitButtonPosition, buttonSize))
			{
				CP_Engine_Terminate();
			}
			return;
		}
		else if (Detect_button(mousePos, gPauseButtonPosition, buttonSize))
		{
			isOnBall = FALSE;
			gIsPaused = TRUE;
			return;
		}
		if (isOverBall)
		{
			isOnBall = TRUE;
		}
	}

	if (!gIsPaused && isOnBall)
	{
		Sarah_DetectBall(mousePos);
	}
}


void Sarah_HoverButton(void) {
	gButtonColor = COLOR_WHITE;
	CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());

	if (Detect_button(mousePos, gPauseButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_PAUSE;
	}
	else if (Detect_button(mousePos, gResumeButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_RESUME;

	}

	else if (Detect_button(mousePos, gRestartButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_RESTART;

	}

	else if (Detect_button(mousePos, gMainMenuButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_MAINMENU;

	}

	else if (Detect_button(mousePos, gLeftButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_LEFT;

	}

	else if (SceneManagerGetCurrentIndex() != Level_Three && Detect_button(mousePos, gRightButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_RIGHT;

	}

	else if (Detect_button(mousePos, gQuitButtonPosition, buttonSize))
	{
		gButtonColor = COLOR_GREEN;
		gCurrentButtonType = BUTTON_TYPE_QUIT;

	}

}


void Sarah_DetectBall(CP_Vector mousePos)
{
	//if mouse dragged, get new position to minus ball position for ball to move opposite direction
	CP_Vector updatedPos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());

	if (CP_Input_MouseReleased(MOUSE_BUTTON_LEFT))
	{
		//Ball will move to final position(current ball position + velocity)
		player->vel = CP_Vector_Subtract(player->pos, updatedPos);
		if (CP_Vector_DotProduct(player->vel, player->vel) > MAXBALLSPEED * MAXBALLSPEED)
			player->vel = CP_Vector_Scale(CP_Vector_Normalize(player->vel), MAXBALLSPEED);
		Play_SFX(SFX_HIT + player->onSpecialTrigger);
		isOnBall = FALSE;
		++hitNo;
	}
}

void Sarah_Update(void)
{
	SceneManagerUpdate();

	if (gIsPaused || gameOver)
		return;

	float dt = CP_System_GetDt();
	for (int i = 0; i < GAMEOBJECTSIZE; i++)
	{
		GameObject* go = gameobjectList[i];

		if (!go->enable)
			continue;

		if (go->colorType == GO_PLAYER)
		{
			if (go->inWater)
			{
				timer += dt;
				if (timer > 1)
					timer = 1;
				continue;
			}
			Update_Velocity(&(go->vel), go->onSpecialTrigger);
			if (CP_Vector_Length(player->vel) == 0)
				player->otherPos = player->pos;
			go->onSpecialTrigger = 0;
		}

		go->pos = CP_Vector_Add(go->pos, CP_Vector_Scale(go->vel, dt));


		for (int j = i; j < GAMEOBJECTSIZE; j++)
		{
			GameObject* go2 = gameobjectList[j];
			if (!go2->enable)
				continue;

			if (IsCollided(go, go2))
			{
				CollidedReaction(go, go2);
			}
		}
	}

	if ((!goal->onSpecialTrigger && hitNo < MAXHIT) || (hitNo >= MAXHIT && CP_Vector_Length(player->vel) != 0))
		return;
	gameOver = 1;
}

void Sarah_RenderUI(void)
{
	CP_Settings_Fill(CP_Color_Create(50, 50, 50, 255));

	CP_Graphics_DrawRect(CP_System_GetWindowWidth() * .5f, (BUTTON_HEIGHT + 20) * .5f, (float)CP_System_GetWindowWidth(), BUTTON_HEIGHT + 20);
	/* This will set the 'fill' to white color */
	CP_Settings_Fill(COLOR_WHITE);

	CP_Graphics_DrawRect(gPauseButtonPosition.x, gPauseButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);

	if (gCurrentButtonType == BUTTON_TYPE_PAUSE)
	{
		CP_Settings_Fill(gButtonColor);
		CP_Graphics_DrawRect(gPauseButtonPosition.x, gPauseButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	}

	/* This will set the 'fill' with black color */
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));

	CP_Settings_TextSize(25.f);

	CP_Font_DrawText("Pause", gPauseButtonPosition.x - 28.f, gPauseButtonPosition.y);

	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));

	char text[100];
	sprintf_s(text, 100, "Hit : %d / %d", hitNo, MAXHIT);
	CP_Font_DrawText(text, gPauseButtonPosition.x - 270.f, gPauseButtonPosition.y + 10.f);

	sprintf_s(text, 100, "Level : %d", SceneManagerGetCurrentIndex() % Level_One + 1);
	CP_Font_DrawText(text, gPauseButtonPosition.x - 430.f, gPauseButtonPosition.y + 10.f);

	if (gIsPaused == TRUE)
	{
		/* This will set the 'fill' with black color */
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Settings_TextSize(80.f);
		CP_Font_DrawText("PAUSE", CP_System_GetWindowWidth() * .37f, 130.f);

		/* This will set the 'fill' to white color */
		CP_Settings_Fill(COLOR_WHITE);

		CP_Graphics_DrawRect(gResumeButtonPosition.x, gResumeButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		CP_Graphics_DrawRect(gRestartButtonPosition.x, gRestartButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		CP_Graphics_DrawRect(gMainMenuButtonPosition.x, gMainMenuButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		CP_Graphics_DrawRect(gQuitButtonPosition.x, gQuitButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);

		if (gCurrentButtonType == BUTTON_TYPE_RESUME)
		{
			CP_Settings_Fill(gButtonColor);
			CP_Graphics_DrawRect(gResumeButtonPosition.x, gResumeButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}
		else if (gCurrentButtonType == BUTTON_TYPE_RESTART)
		{
			CP_Settings_Fill(gButtonColor);
			CP_Graphics_DrawRect(gRestartButtonPosition.x, gRestartButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}

		else if (gCurrentButtonType == BUTTON_TYPE_MAINMENU)
		{
			CP_Settings_Fill(gButtonColor);
			CP_Graphics_DrawRect(gMainMenuButtonPosition.x, gMainMenuButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}

		else if (gCurrentButtonType == BUTTON_TYPE_QUIT)
		{
			CP_Settings_Fill(gButtonColor);
			CP_Graphics_DrawRect(gQuitButtonPosition.x, gQuitButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
		}

		/* This will set the 'fill' with black color */
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Settings_TextSize(25.f);
		CP_Font_DrawText("Resume Game", gResumeButtonPosition.x - 60.f, gResumeButtonPosition.y);

		CP_Font_DrawText("Restart Game", gRestartButtonPosition.x - 60.f, gRestartButtonPosition.y);

		CP_Font_DrawText("Return to Main Menu", gMainMenuButtonPosition.x - 93.f, gMainMenuButtonPosition.y);

		CP_Font_DrawText("Quit Game", gQuitButtonPosition.x - 43.f, gQuitButtonPosition.y);
		return;
	}

	if (!gameOver)
		return;

	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 150));
	CP_Graphics_DrawRect(CP_System_GetWindowWidth() * .5f, CP_System_GetWindowHeight() * .5f, (float)CP_System_GetWindowWidth(), (float)CP_System_GetWindowHeight());
	/* This will set the 'fill' with black color */
	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
	CP_Settings_TextSize(60.f);
	CP_Font_DrawText(goal->onSpecialTrigger ? "You Win" : "You Lose", CP_System_GetWindowWidth() * .45f - 58, CP_System_GetWindowHeight() * .35f);
	CP_Settings_TextSize(25.f);
	//win condition
	//check if ball is at the hole position and max hit is 12
		/* This will set the 'fill' to white color */
	CP_Settings_Fill(COLOR_WHITE);
	CP_Graphics_DrawRect(gLeftButtonPosition.x, gLeftButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	CP_Graphics_DrawRect(gRightButtonPosition.x, gRightButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	if (gCurrentButtonType == BUTTON_TYPE_LEFT)
	{
		CP_Settings_Fill(gButtonColor);
		CP_Graphics_DrawRect(gLeftButtonPosition.x, gLeftButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	}
	else if (SceneManagerGetCurrentIndex() != Level_Three && gCurrentButtonType == BUTTON_TYPE_RIGHT)
	{
		CP_Settings_Fill(gButtonColor);
		CP_Graphics_DrawRect(gRightButtonPosition.x, gRightButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
	}

	/* This will set the 'fill' with black color */
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Font_DrawText("Exit to Main Menu", gLeftButtonPosition.x - 82.f, gLeftButtonPosition.y);

	/* This will set the 'fill' with black color */
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Font_DrawText(goal->onSpecialTrigger ? "Next Level" : "Restart Game", gRightButtonPosition.x - 50.f, gRightButtonPosition.y);
}

void Sarah_Render(void)
{
	//draw
	/* This will fill the background with blue color */
	if (SceneManager_GetOverlayPercentage() < 1)
	{
		CP_Graphics_ClearBackground(CP_Color_Create(0, 255, 0, 255));

		for (int i = 0; i < GAMEOBJECTSIZE; i++)
		{
			GameObject* go = gameobjectList[i];
			GameObjectColorType colorType = go->colorType;
			if (!go->enable)
				continue;
			CP_Color color;
			CP_Vector scale = go->scale, pos = go->pos;
			switch (colorType)
			{
			case GO_PLAYER:
				CP_Settings_Stroke(CP_Color_Create(255 * isOverBall, 255 * isOverBall, 0, 255));
				CP_Settings_StrokeWeight(2);
				CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
				if (go->inWater)
				{
					pos = EaseInOutQuad(go->pos, go->otherPos, timer);
					if (timer >= 1)
					{
						go->inWater = 0;
						timer = 0;
						go->pos = go->otherPos;
					}
				}
				break;
			case GO_WALL:
				CP_Settings_Stroke(CP_Color_Create(0, 0, 0, 255));
				CP_Settings_StrokeWeight(3);
				CP_Settings_Fill(CP_Color_Create(139, 69, 19, 255));
				scale.x -= 3;
				scale.y -= 3;
				break;
			case GO_WATER:
				color = CP_Color_Create(0, 0, 255, 255);
				CP_Settings_Stroke(color);
				CP_Settings_StrokeWeight(1);
				CP_Settings_Fill(color);
				scale.x += 10;
				scale.y += 10;
				break;
			case GO_SAND:
				color = CP_Color_Create(226, 202, 118, 255);
				CP_Settings_Stroke(color);
				CP_Settings_StrokeWeight(1);
				CP_Settings_Fill(color);
				scale.x += 10;
				scale.y += 10;
				break;
			case GO_WIND:
				color = CP_Color_Create(0, 128, 128, 150);
				CP_Settings_Stroke(color);
				CP_Settings_StrokeWeight(1);
				CP_Settings_Fill(color);
				scale.x += 10;
				scale.y += 10;
				break;
			case GO_TUNNEL:
				color = CP_Color_Create(60, 60, 60, 255);
				CP_Settings_Stroke(color);
				CP_Settings_StrokeWeight(1);
				CP_Settings_Fill(color);
				scale.x += 10;
				scale.y += 10;
				break;
			case GO_GOAL:
				color = CP_Color_Create(10, 10, 10, 255);
				CP_Settings_Stroke(color);
				CP_Settings_StrokeWeight(1);
				CP_Settings_Fill(color);
				scale.x += 10;
				scale.y += 10;
				break;
			}

			switch (go->renderType)
			{
			case GO_CIRCLE:
				CP_Graphics_DrawCircle(pos.x, pos.y, go->scale.x * 2);
				break;
			case GO_BOX:
				CP_Graphics_DrawRectAdvanced(pos.x, pos.y, scale.x, scale.y, CP_Math_Degrees(atan2f(go->dir.y, go->dir.x)), 0);
				break;
			}
		}

		CP_Settings_Stroke(CP_Color_Create(0, 0, 0, 255));
		CP_Settings_StrokeWeight(1);
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		CP_Graphics_DrawRect(goal->pos.x, goal->pos.y - 25, 7, 50);
		CP_Settings_Fill(CP_Color_Create(255, 0, 0, 255));
		CP_Graphics_DrawTriangle(goal->pos.x + 3.5f, goal->pos.y - 50, goal->pos.x + 3.5f, goal->pos.y - 25, goal->pos.x + 25, goal->pos.y - 37.5f);

		if (isOnBall == TRUE)
		{
			CP_Settings_Stroke(CP_Color_Create(0, 0, 0, 255));
			CP_Vector mouse = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
			CP_Vector relative = CP_Vector_Subtract(mouse, player->pos);
			if (CP_Vector_DotProduct(relative, relative) > (MAXBALLSPEED - 100) * (MAXBALLSPEED - 100))
				relative = CP_Vector_Scale(CP_Vector_Normalize(relative), MAXBALLSPEED - 100);
			CP_Settings_StrokeWeight(2);
			CP_Graphics_DrawLine(player->pos.x - relative.x, player->pos.y - relative.y, player->pos.x, player->pos.y);
		}
	}
}

GameObject* Sarah_GetGO()
{
	GameObject* go;
	for (int i = 0; i < GAMEOBJECTSIZE; i++)
	{
		go = gameobjectList[i];
		if (go->enable)
			continue;

		go->enable = 1;
		break;
	}

	return go;
}