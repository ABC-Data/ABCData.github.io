﻿/*---------------------------------------------------------
 * file:	GameObject.h
 * author:	Desmond peh han yong
 * email:	desmondhanyong.peh@digipen.edu
 *
 * brief:	Declaration of GameObjects Functions
 *
 * Copyright @ 2021 DigiPen, All rights reserved.
 *---------------------------------------------------------*/
#pragma once
#include "cprocessing.h"
#include <math.h>
#define BALLMAXSPEED 20

typedef enum GameObjectRenderType
{
	GO_NONE,
	GO_CIRCLE,
	GO_BOX
} GameObjectRenderType;

typedef enum GameObjectColorType
{
	GO_NOCOLOR,
	GO_PLAYER,
	GO_MOVABLEBALL,
	GO_WALL,
	GO_WATER,
	GO_SAND,
	GO_WIND,
	GO_TUNNEL,
	GO_GOAL,
	GO_LAST
} GameObjectColorType;

typedef struct
{
	int enable, onSpecialTrigger, inWater;
	GameObjectRenderType renderType;
	GameObjectColorType colorType;
	CP_Vector pos, vel, scale, otherPos, dir;
	float mass, otherRadius, windSpeed;
} GameObject;

void GameObject_Init(GameObject* go);

int IsCollided(GameObject* GOA, GameObject* GOB);
int CircleToCircle(GameObject* GOA, GameObject* GOB);
int CircleToBox(GameObject* GOA, GameObject* GOB);
int BoxToBox(GameObject* GOA, GameObject* GOB);


static CP_Vector EaseInOutQuad(CP_Vector start, CP_Vector end, float value)
{
	value /= .5f;
	end = CP_Vector_Subtract(end, start);
	if (value < 1) return CP_Vector_Add(CP_Vector_Scale(end, 0.5f * value * value), start);
	value--;
	return CP_Vector_Add(CP_Vector_Scale(CP_Vector_Negate(end) ,0.5f * (value * (value - 2) - 1)), start);
}


void CollidedReaction(GameObject* GOA, GameObject* GOB);
void CircleToCircleReaction(GameObject* GOA, GameObject* GOB);
void CircleToBoxReaction(GameObject* GOA, GameObject* GOB);
void BoxToBoxReaction(GameObject* GOA, GameObject* GOB);
void SpecialReaction(GameObject* GOA, GameObject* GOB);