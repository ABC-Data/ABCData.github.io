/*---------------------------------------------------------
 * file:	Credits2.h
 * author:	Sarah Tan Yu Hong
 * email:	sarahyuhong.t@digipen.edu
 *
 * brief:	This file declare functions that help to create the game credits.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/

#pragma once

#include "GameObject.h"
void Credits2_init(void);
void Credits2_update(void);
void Credits2_exit(void);
void Credits2_HandleInput(void);
void Credits2_Update(void);
void Credits2_Render(void);
void Credits2_HoverButton(void);
