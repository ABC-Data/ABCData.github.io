﻿/*---------------------------------------------------------
 * file:	Audio.h
 * author:	Desmond peh han yong
 * email:	desmondhanyong.peh@digipen.edu
 *
 * brief:	Declaration of Audios Functions
 *
 * Copyright @ 2021 DigiPen, All rights reserved.
 *---------------------------------------------------------*/
#pragma once
#include "cprocessing.h"

typedef enum SFX_Type
{
	SFX_GOAL = 0,
	SFX_WATER,
	SFX_TUNNEL,
	SFX_HIT,
	SFX_HIT_SAND,
	SFX_HIT_WALL,
	SFX_LAST
}SFX_Type;

CP_Sound BGM, SFX[SFX_LAST];
void Audio_Init(void);
void Play_SFX(SFX_Type type);
void Free_Sound(void);