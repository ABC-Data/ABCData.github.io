/*---------------------------------------------------------
 * file:	HowToPlay.c
 * author:	Sarah Tan Yu Hong
 * email:	sarahyuhong.t@digipen.edu
 *
 * brief:	This file contain functions that help to create the how to play section of the game which
		    indicate the rule of game and the controls.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h> 
#include "cprocessing.h"
#include "mouseinput.h"
#include "SceneManager.h"
#include "Audio.h"
#include "HowToPlay.h"

#define BUTTON_WIDTH 230.f
#define BUTTON_HEIGHT 60.f


CP_Vector gMainMenuButtonPosition;
CP_Vector gNextButtonPosition;
CP_Vector buttonSize;
CP_Vector nextButtonSize;

CP_Color gButtonColor;
#define BUTTON_TYPE_MAINMENU 0
#define BUTTON_TYPE_NEXT 1
int gCurrentButtonType;
#define COLOR_GREEN CP_Color_Create(0, 255, 0, 255)
#define COLOR_WHITE CP_Color_Create(255, 255, 255, 255)

typedef struct _Particle
{
	CP_Vector pos;
	CP_Vector vel;
	CP_Color* color;
} Particle;

const float EPSILON3 = 0.0000001f;

Particle particles[30];
int numParticles3 = 30, nextLevel;

float circleProximityDistance3 = 100.0f;

CP_Color color;

CP_Color randomColors3[] = {
	{ 128, 0,   0,   255 },
	{ 128, 128, 0,   255 },
	{ 0,   128, 0,   255 },
	{ 0,   128, 128, 255 },
	{ 0,   0,   128, 255 },
	{ 128, 0,   128, 255 } };

void ParticleCreate3(Particle* part) {

	part->pos.x = CP_Random_RangeFloat(0, (float)CP_System_GetWindowWidth());
	part->pos.y = CP_Random_RangeFloat(0, (float)CP_System_GetWindowHeight());
	part->vel.x = CP_Random_RangeFloat(-150, 150);
	part->vel.y = CP_Random_RangeFloat(-150, 150);
	part->color = &randomColors3[CP_Random_RangeInt(0, 5)];
}


void ParticleUpdate3(Particle* part)
{

	// move particle based on velocity and correct for wall collisions
	float time = CP_System_GetDt();
	float timeX = time;
	float timeY = time;

	while (time > EPSILON3)
	{
		int collisionX = FALSE;
		int collisionY = FALSE;

		float newPosX = part->pos.x + part->vel.x * time;
		float newPosY = part->pos.y + part->vel.y * time;
		float newTime = time;

		// check wall collisions X and Y
		if (newPosX <= 0)
		{
			timeX = part->pos.x / (part->pos.x - newPosX) * time;
			collisionX = TRUE;
		}
		else if (newPosX >= CP_System_GetWindowWidth())
		{
			timeX = (CP_System_GetWindowWidth() - part->pos.x) / (newPosX - part->pos.x) * time;
			collisionX = TRUE;
		}

		if (newPosY <= 0)
		{
			timeY = part->pos.y / (part->pos.y - newPosY) * time;
			collisionY = TRUE;
		}
		else if (newPosY >= CP_System_GetWindowHeight())
		{
			timeY = (CP_System_GetWindowHeight() - part->pos.y) / (newPosY - part->pos.y) * time;
			collisionY = TRUE;
		}

		// resolve collisions
		if ((collisionX == TRUE) || (collisionY == TRUE))
		{

			// take the nearest time
			if (timeX < timeY)
			{
				newTime = timeX;
			}
			else
			{
				newTime = timeY;
			}

			// move the particle
			part->pos.x += part->vel.x * newTime;
			part->pos.y += part->vel.y * newTime;

			// flip velocity vectors to reflect off walls
			if ((collisionX == TRUE) && (collisionY == FALSE))
			{
				part->vel.x *= -1;
			}
			else if ((collisionX == FALSE) && (collisionY == TRUE))
			{
				part->vel.y *= -1;
			}
			else
			{	// they must both be colliding for this condition to occur
				if (timeX < timeY)
				{
					part->vel.x *= -1;
				}
				else if (timeX > timeY)
				{
					part->vel.y *= -1;
				}
				else
				{	// they must be colliding at the same time (ie. a corner)
					part->vel.x *= -1;
					part->vel.y *= -1;
				}
			}

			// decrease time and iterate
			time -= newTime;
		}
		else
		{
			// no collision
			part->pos.x = newPosX;
			part->pos.y = newPosY;
			time = 0;
		}
	}
}




void HowToPlay_init(void)
{

    for (int i = 0; i < numParticles3; ++i) {
        ParticleCreate3(&particles[i]);
    }

    gButtonColor = COLOR_WHITE;
	nextLevel = 0;
	CP_Settings_RectMode(CP_POSITION_CENTER);
	gMainMenuButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .800f, CP_System_GetWindowWidth() * .900f);
    gNextButtonPosition = CP_Vector_Set(CP_System_GetWindowWidth() * .890f, CP_System_GetWindowWidth() * .410f);

	buttonSize = CP_Vector_Set(BUTTON_WIDTH, BUTTON_HEIGHT);
	nextButtonSize = CP_Vector_Set(100, BUTTON_HEIGHT);
}

void HowToPlay_update(void)
{

	HowToPlay_HandleInput();
	HowToPlay_Update();
	HowToPlay_Render();
	SceneManagerRenderBlack();
    HowToPlay_HoverButton();
}

void HowToPlay_exit(void)
{
	if (!nextLevel)
		Free_Sound();
}

void HowToPlay_HandleInput()
{
	if (SceneManager_IsTransitioning())
		return;

	CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
	if (CP_Input_MouseTriggered(MOUSE_BUTTON_1))
	{
		//Back to Main Menu
		if (Detect_button(mousePos, gMainMenuButtonPosition, buttonSize))
		{
			SceneManagerSetNextScene(MainMenuScene);
			nextLevel = 1;
		}

		else if (Detect_button(mousePos, gNextButtonPosition, nextButtonSize))
		{
			SceneManagerSetNextScene(HowToPlay2_Scene);
			nextLevel = 1;
		}

	}
}

void HowToPlay_HoverButton(void) {
    gButtonColor = COLOR_WHITE;
    CP_Vector mousePos = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
    
    if (Detect_button(mousePos, gMainMenuButtonPosition, buttonSize))
    {
        gButtonColor = COLOR_GREEN;
        gCurrentButtonType = BUTTON_TYPE_MAINMENU;

    }
    
    else if (Detect_button(mousePos, gNextButtonPosition, nextButtonSize))
    {
        gButtonColor = COLOR_GREEN;
        gCurrentButtonType = BUTTON_TYPE_NEXT;
    }
   
}

void HowToPlay_Update(void)
{
	SceneManagerUpdate();
}

void HowToPlay_Render(void)
{

	if (SceneManager_GetOverlayPercentage() < 1.f)
	{


		CP_Settings_BlendMode(CP_BLEND_ALPHA);
		CP_Graphics_ClearBackground(CP_Color_Create(0, 0, 0, 255));


		for (int i = 0; i < numParticles3; ++i)
		{
			ParticleUpdate3(&particles[i]);
		}

		/* CP_Settings_BlendMode(CP_BLEND_ADD);*/
		CP_Settings_StrokeWeight(3);


		for (int i = 0; i < numParticles3; ++i)
		{

			for (int j = i + 1; j < numParticles3; ++j)
			{
				float distX = (float)fabsf(particles[i].pos.x - particles[j].pos.x);
				float distY = (float)fabsf(particles[i].pos.y - particles[j].pos.y);
				if (distX < circleProximityDistance3 && distY < circleProximityDistance3)
				{
					color.r = particles[i].color->r + particles[j].color->r;
					color.g = particles[i].color->g + particles[j].color->g;
					color.b = particles[i].color->b + particles[j].color->b;
					color.a = (unsigned char)(255.0f * min(1.0f, (circleProximityDistance3 - max(distX, distY)) / (circleProximityDistance3 * 0.3f)));
					CP_Settings_Stroke(color);
					CP_Graphics_DrawCircle(particles[i].pos.x, particles[i].pos.y, 20);
				}
			}
		}

		/* This will set the 'fill' with white color */
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		CP_Settings_TextSize(70.f);
		CP_Font_DrawText("How to Play", CP_System_GetWindowWidth() * .30f, CP_System_GetWindowHeight() * .10f);

		/* This will set the 'fill' with green color */
		CP_Settings_Fill(CP_Color_Create(0, 255, 0, 255));
		CP_Settings_TextSize(25.f);
		CP_Font_DrawText("Project Golf is a brilliant adventure golf game to overcome various ", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .25f);
		CP_Font_DrawText("obstacles and hit the ball in the hole using as few hits (max 12 hits) ", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .30f);
		CP_Font_DrawText("as possible to complete all stages of the game.", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .35f);

		/* This will set the 'fill' with purple color */
		CP_Settings_Fill(CP_Color_Create(127, 0, 255, 255));
		CP_Settings_TextSize(40.f);
		CP_Font_DrawText("Controls", CP_System_GetWindowWidth() * .40f, CP_System_GetWindowHeight() * .45f);
		
		CP_Settings_Fill(CP_Color_Create(0, 255, 255, 255));
		CP_Settings_TextSize(25.f);
		CP_Font_DrawText("Drag the left mouse button to aim and adjust power; release it to shoot.", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .50f);
		CP_Font_DrawText("Press the key P to pause the game.", CP_System_GetWindowWidth() * 0.05f, CP_System_GetWindowHeight() * .55f);

		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		// Draw a mouse
		CP_Graphics_DrawEllipse(CP_System_GetWindowWidth() * .20f, CP_System_GetWindowHeight() * .75f, 150.0f, 200.0f);

		// set the stroke color to orange
		CP_Settings_Stroke(CP_Color_Create(255, 160, 20, 255));

		CP_Graphics_DrawLine(70.0f, 520.0f, 215.0f, 520.0f);
		CP_Graphics_DrawLine(145.0f, 520.0f, 145.0f, 440.0f);

		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("Shoot", CP_System_GetWindowWidth() * 0.12f, CP_System_GetWindowHeight() * .70f);
		CP_Font_DrawText("Aim", CP_System_GetWindowWidth() * 0.17f, CP_System_GetWindowHeight() * .80f);

		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		CP_Font_DrawText("Pause", gMainMenuButtonPosition.x - 130.f, gMainMenuButtonPosition.y - 220.f);

		CP_Settings_Fill(CP_Color_Create(255, 160, 20, 255));

		CP_Graphics_DrawRect(gMainMenuButtonPosition.x - 100.f, gMainMenuButtonPosition.y - 150.f, 80, 80);
		CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
		CP_Font_DrawText("P", gMainMenuButtonPosition.x - 105.f, gMainMenuButtonPosition.y - 150.f);
        
        CP_Settings_Stroke(CP_Color_Create(0, 0, 0, 255));
        CP_Settings_Fill(COLOR_WHITE);
        CP_Graphics_DrawRect(gNextButtonPosition.x, gNextButtonPosition.y, 100, BUTTON_HEIGHT);

		CP_Graphics_DrawRect(gMainMenuButtonPosition.x, gMainMenuButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);

        if (gCurrentButtonType == BUTTON_TYPE_NEXT)
        {
            CP_Settings_Fill(gButtonColor);
            CP_Graphics_DrawRect(gNextButtonPosition.x, gNextButtonPosition.y, 100, BUTTON_HEIGHT);
        }
        if (gCurrentButtonType == BUTTON_TYPE_MAINMENU)
        {
            CP_Settings_Fill(gButtonColor);
            CP_Graphics_DrawRect(gMainMenuButtonPosition.x, gMainMenuButtonPosition.y, BUTTON_WIDTH, BUTTON_HEIGHT);
        }
        /* This will set the 'fill' with black color */
        CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));

        CP_Font_DrawText("Next", gNextButtonPosition.x - 20.f, gNextButtonPosition.y);

        CP_Font_DrawText("Exit to Main Menu", gMainMenuButtonPosition.x - 80.f, gMainMenuButtonPosition.y);

	}
}

