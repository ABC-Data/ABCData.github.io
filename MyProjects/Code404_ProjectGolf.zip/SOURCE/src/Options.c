﻿/*---------------------------------------------------------
 * file:	Options.c
 * author:	Warren Ang Jun Xuan
 *			Desmond Peh Han Yong
 * email:	a.warrenjunxuan@digipen.edu
 *			desmondhanyong.peh@digipen.edu
 *
 * brief:	Options for music and sfx volume control.(Warren)
 *			Implementation of Audio.c with volume control.(Desmond)
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/
#include "Options.h"
#include "mouseinput.h"
#include "Audio.h"
#include "SceneManager.h"


typedef struct _Particle
{
	CP_Vector pos;
	CP_Vector vel;
	CP_Color* color;
} Particle;

const float EPSILON2 = 0.0000001f;

Particle particles[30];
int numParticles2 = 30, nextLevel;

float circleProximityDistance2 = 100.0f;

CP_Color color;

CP_Color randomColors2[] = {
	{ 128, 0,   0,   255 },
	{ 128, 128, 0,   255 },
	{ 0,   128, 0,   255 },
	{ 0,   128, 128, 255 },
	{ 0,   0,   128, 255 },
	{ 128, 0,   128, 255 } };

void ParticleCreate2(Particle* part) {

	part->pos.x = CP_Random_RangeFloat(0, (float)CP_System_GetWindowWidth());
	part->pos.y = CP_Random_RangeFloat(0, (float)CP_System_GetWindowHeight());
	part->vel.x = CP_Random_RangeFloat(-150, 150);
	part->vel.y = CP_Random_RangeFloat(-150, 150);
	part->color = &randomColors2[CP_Random_RangeInt(0, 5)];
}


void ParticleUpdate2(Particle* part)
{

	// move particle based on velocity and correct for wall collisions
	float time = CP_System_GetDt();
	float timeX = time;
	float timeY = time;

	while (time > EPSILON2)
	{
		int collisionX = FALSE;
		int collisionY = FALSE;

		float newPosX = part->pos.x + part->vel.x * time;
		float newPosY = part->pos.y + part->vel.y * time;
		float newTime = time;

		// check wall collisions X and Y
		if (newPosX <= 0)
		{
			timeX = part->pos.x / (part->pos.x - newPosX) * time;
			collisionX = TRUE;
		}
		else if (newPosX >= CP_System_GetWindowWidth())
		{
			timeX = (CP_System_GetWindowWidth() - part->pos.x) / (newPosX - part->pos.x) * time;
			collisionX = TRUE;
		}

		if (newPosY <= 0)
		{
			timeY = part->pos.y / (part->pos.y - newPosY) * time;
			collisionY = TRUE;
		}
		else if (newPosY >= CP_System_GetWindowHeight())
		{
			timeY = (CP_System_GetWindowHeight() - part->pos.y) / (newPosY - part->pos.y) * time;
			collisionY = TRUE;
		}

		// resolve collisions
		if ((collisionX == TRUE) || (collisionY == TRUE))
		{

			// take the nearest time
			if (timeX < timeY)
			{
				newTime = timeX;
			}
			else
			{
				newTime = timeY;
			}

			// move the particle
			part->pos.x += part->vel.x * newTime;
			part->pos.y += part->vel.y * newTime;

			// flip velocity vectors to reflect off walls
			if ((collisionX == TRUE) && (collisionY == FALSE))
			{
				part->vel.x *= -1;
			}
			else if ((collisionX == FALSE) && (collisionY == TRUE))
			{
				part->vel.y *= -1;
			}
			else
			{	// they must both be colliding for this condition to occur
				if (timeX < timeY)
				{
					part->vel.x *= -1;
				}
				else if (timeX > timeY)
				{
					part->vel.y *= -1;
				}
				else
				{	// they must be colliding at the same time (ie. a corner)
					part->vel.x *= -1;
					part->vel.y *= -1;
				}
			}

			// decrease time and iterate
			time -= newTime;
		}
		else
		{
			// no collision
			part->pos.x = newPosX;
			part->pos.y = newPosY;
			time = 0;
		}
	}
}


void Options_init(void)
{
	for (int i = 0; i < numParticles2; ++i) {
		ParticleCreate2(&particles[i]);
	}
	nextLevel = 0;
}

void Options_update(void)
{
	SceneManagerUpdate();
	option_tab();
}

void Options_exit(void)
{
	if (!nextLevel)
		Free_Sound();
}

void option_tab()
{
	CP_Settings_BlendMode(CP_BLEND_ALPHA);
	CP_Graphics_ClearBackground(CP_Color_Create(0, 0, 0, 255));


	for (int i = 0; i < numParticles2; ++i)
	{
		ParticleUpdate2(&particles[i]);
	}

	//CP_Settings_BlendMode(CP_BLEND_ADD);
	CP_Settings_StrokeWeight(3);


	for (int i = 0; i < numParticles2; ++i)
	{
		for (int j = i + 1; j < numParticles2; ++j)
		{
			float distX = (float)fabsf(particles[i].pos.x - particles[j].pos.x);
			float distY = (float)fabsf(particles[i].pos.y - particles[j].pos.y);
			if (distX < circleProximityDistance2 && distY < circleProximityDistance2)
			{
				color.r = particles[i].color->r + particles[j].color->r;
				color.g = particles[i].color->g + particles[j].color->g;
				color.b = particles[i].color->b + particles[j].color->b;
				color.a = (unsigned char)(255.0f * min(1.0f, (circleProximityDistance2 - max(distX, distY)) / (circleProximityDistance2 * 0.3f)));
				CP_Settings_Stroke(color);
				CP_Graphics_DrawCircle(particles[i].pos.x, particles[i].pos.y, 20);
			}
		}
	}
	CP_Settings_NoStroke();
	/* This will set the 'fill' with white color */
	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
	CP_Settings_TextSize(70.f);
	CP_Font_DrawText("Options", CP_System_GetWindowWidth() * .36f, CP_System_GetWindowHeight() * .15f);

	//Open options menu in the middle of screen
	float audio_x = CP_System_GetWindowWidth() / 2.f;
	float audio_y = CP_System_GetWindowHeight() / 2.f;

	//audio tab
	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
	CP_Settings_TextSize(25.f);
	CP_Graphics_DrawRect(audio_x, audio_y, width, height);
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Font_DrawText("Audio", audio_x - 27.f, audio_y - 120.f);
	//back button
	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
	CP_Graphics_DrawRect(audio_x - 142.f, audio_y - 143.f, 15.f, 15.f);
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Font_DrawText("X", audio_x - 148.f, audio_y - 136.f);
	//music volume
	music_vol = music(audio_x, audio_y, music_vol);
	//sfx
	sfx_vol = sfx(audio_x, audio_y, sfx_vol);
	CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, music_vol / 10.f);
	CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, sfx_vol / 10.f);
	if (CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT))
	{
		CP_Vector Back_button_size = CP_Vector_Set(15.f, 15.f);
		CP_Vector mouse = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
		//CP_Vector Back_button = CP_Vector_Set(audio_x+7.5f, audio_y+7.5f);
		CP_Vector Back_button = CP_Vector_Set(audio_x - 142.f, audio_y - 140.f);
		//if back button or esc key is press, go back to mainmenu/game
		if ((Detect_button(mouse, Back_button, Back_button_size) == 1) || CP_Input_KeyTriggered(KEY_ESCAPE) == 1)
		{
			SceneManagerSetNextScene(MainMenuScene);
			nextLevel = 1;
		}
	}
	SceneManagerRenderBlack();
}

int music(float audio_x, float audio_y, int volume)
{
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Font_DrawText("Music", audio_x - 27.f, audio_y - 65.f);
	//decrease volume button
	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
	CP_Graphics_DrawRect(audio_x - 75.f, audio_y - 30.f, 15.f, 40.f);
	//increase volume button
	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
	CP_Graphics_DrawRect(audio_x + 75.f, audio_y - 30.f, 15.f, 40.f);

	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Graphics_DrawTriangle(audio_x - 67.5f, audio_y - 50.f, audio_x - 68.5f, audio_y - 10.f, audio_x - 82.5f, audio_y - 30.f);
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Graphics_DrawTriangle(audio_x + 67.5f, audio_y - 50.f, audio_x + 68.5f, audio_y - 10.f, audio_x + 82.5f, audio_y - 30.f);
	if (CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT))
	{
		CP_Vector mouse = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
		CP_Vector Decrease_volume_button_size = CP_Vector_Set(15.f, 40.f);
		CP_Vector Decrease_volume_button = CP_Vector_Set(audio_x - 75.f, audio_y - 30.f);
		CP_Vector Increase_volume_button_size = CP_Vector_Set(15.f, 40.f);
		CP_Vector Increase_volume_button = CP_Vector_Set(audio_x + 75.f, audio_y - 30.f);

		if (Detect_button(mouse, Decrease_volume_button, Decrease_volume_button_size) == 1)
		{
			volume == 0 ? volume = 0 : --volume;
		}

		if (Detect_button(mouse, Increase_volume_button, Increase_volume_button_size) == 1)
		{
			volume == 10 ? volume = 10 : ++volume;
		}
	}
	switch (volume)
	{
	case 0: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("Mute", audio_x - 25.f, audio_y - 30.f);
		break;
	case 1: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("1", audio_x - 5.f, audio_y - 30.f);
		break;
	case 2: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("2", audio_x - 5.f, audio_y - 30.f);
		break;
	case 3: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("3", audio_x - 5.f, audio_y - 30.f);
		break;
	case 4: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("4", audio_x - 5.f, audio_y - 30.f);
		break;
	case 5: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("5", audio_x - 5.f, audio_y - 30.f);
		break;
	case 6: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("6", audio_x - 5.f, audio_y - 30.f);
		break;
	case 7: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("7", audio_x - 5.f, audio_y - 30.f);
		break;
	case 8: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("8", audio_x - 5.f, audio_y - 30.f);
		break;
	case 9: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("9", audio_x - 5.f, audio_y - 30.f);
		break;
	case 10: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("Max", audio_x - 21.f, audio_y - 30.f);
		break;
	}
	return volume;
}

int sfx(float audio_x, float audio_y, int volume)
{
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Font_DrawText("SFX", audio_x - 18.f, audio_y + 40.f);
	//decrease volume button
	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
	CP_Graphics_DrawRect(audio_x - 75.f, audio_y + 70.f, 15.f, 40.f);
	//increase volume button
	CP_Settings_Fill(CP_Color_Create(255, 255, 255, 255));
	CP_Graphics_DrawRect(audio_x + 75.f, audio_y + 70.f, 15.f, 40.f);

	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Graphics_DrawTriangle(audio_x - 67.5f, audio_y + 50.f, audio_x - 68.5f, audio_y + 90.f, audio_x - 82.5f, audio_y + 70.f);
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
	CP_Graphics_DrawTriangle(audio_x + 67.5f, audio_y + 50.f, audio_x + 68.5f, audio_y + 90.f, audio_x + 82.5f, audio_y + 70.f);
	if (CP_Input_MouseTriggered(MOUSE_BUTTON_LEFT))
	{
		CP_Vector mouse = CP_Vector_Set(CP_Input_GetMouseX(), CP_Input_GetMouseY());
		CP_Vector Decrease_volume_button_size = CP_Vector_Set(15.f, 40.f);
		CP_Vector Decrease_volume_button = CP_Vector_Set(audio_x - 75.f, audio_y + 70.f);
		CP_Vector Increase_volume_button_size = CP_Vector_Set(15.f, 40.f);
		CP_Vector Increase_volume_button = CP_Vector_Set(audio_x + 75.f, audio_y + 70.f);

		if (Detect_button(mouse, Decrease_volume_button, Decrease_volume_button_size) == 1)
		{
			volume == 0 ? volume = 0 : --volume;
		}

		if (Detect_button(mouse, Increase_volume_button, Increase_volume_button_size) == 1)
		{
			volume == 10 ? volume = 10 : ++volume;
		}
	}
	switch (volume)
	{
	case 0: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("Mute", audio_x - 25.f, audio_y + 75.f);
		break;
	case 1: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("1", audio_x - 5.f, audio_y + 75.f);
		break;
	case 2: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("2", audio_x - 5.f, audio_y + 75.f);
		break;
	case 3: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("3", audio_x - 5.f, audio_y + 75.f);
		break;
	case 4: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("4", audio_x - 5.f, audio_y + 75.f);
		break;
	case 5: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("5", audio_x - 5.f, audio_y + 75.f);
		break;
	case 6: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("6", audio_x - 5.f, audio_y + 75.f);
		break;
	case 7: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("7", audio_x - 5.f, audio_y + 75.f);
		break;
	case 8: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("8", audio_x - 5.f, audio_y + 75.f);
		break;
	case 9: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("9", audio_x - 5.f, audio_y + 75.f);
		break;
	case 10: CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, (float)volume);
		CP_Settings_Fill(CP_Color_Create(0, 0, 0, 255));
		CP_Font_DrawText("Max", audio_x - 21.f, audio_y + 75.f);
		break;
	}
	return volume;
}
