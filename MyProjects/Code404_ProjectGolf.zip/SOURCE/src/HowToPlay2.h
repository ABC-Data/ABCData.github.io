/*---------------------------------------------------------
 * file:	HowToPlay2.h
 * author:	Sarah Tan Yu Hong
 * email:	sarahyuhong.t@digipen.edu
 *
 * brief:	This file declare functions that help to create the how to play section of the game which
            indicate the rule of game and the controls.
 *
 * documentation link:
 * https://inside.digipen.edu/main/GSDP:GAM100/CProcessing
 *
 * Copyright @ 2020 DigiPen, All rights reserved.
 * ---------------------------------------------------------*/

#pragma once

void HowToPlay2_init(void);
void HowToPlay2_update(void);
void HowToPlay2_exit(void);
void HowToPlay2_HandleInput(void);
void HowToPlay2_Update(void);
void HowToPlay2_Render(void);
void HowToPlay2_HoverButton(void);