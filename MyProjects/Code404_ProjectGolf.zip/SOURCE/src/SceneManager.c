﻿/*---------------------------------------------------------
 * file:	Audio.c
 * author:	Desmond peh han yong
 * email:	desmondhanyong.peh@digipen.edu
 *
 * brief:	Defination of Scene Manager Functions
 *
 * Copyright @ 2021 DigiPen, All rights reserved.
 *---------------------------------------------------------*/
#include "SceneManager.h"
#include "SplashScene.h"
#include "MainMenu.h"
#include "Options.h"
#include "HowToPlay.h"
#include "HowToPlay2.h"
#include "Credits.h"
#include "Credits2.h"
#include "Sarah_Level.h"
#include "Warren_Level.h"
#include "Desmond_Level.h"
#include "Audio.h"

int startAnimate, overlay, reverse, goNextScene;
float timer;
typedef struct Scene
{
	void(*init)(void);
	void(*update)(void);
	void(*exit)(void);
}Scene;
SceneIndex index;
Scene scenes[Total_Scene];

void SceneManagerUpdate(void)
{
	if (!startAnimate)
		return;

	timer += (reverse ? -1 : 1) * CP_System_GetDt();
	overlay = (int)((timer > 1 ? 1 : (timer < 0 ? 0 : timer)) * 255);
	if (timer >= 1.5f)
	{
		if (goNextScene)
		{
			reverse = 1;
			goNextScene = 0;
			timer = 1;
			CP_Engine_SetNextGameState(scenes[index].init, scenes[index].update, scenes[index].exit);
		}
	}
	else if (timer <= 0)
	{
		startAnimate = 0;
		reverse = 0;
		overlay = 0;
		goNextScene = 0;
	}
}

void SceneManagerInit()
{
	startAnimate = 0;
	reverse = 0;
	overlay = 0;
	goNextScene = 0;
	timer = 0;
	index = SplashScene;

	master_vol = 5;
	music_vol = 5;
	sfx_vol = 5;

	CP_Sound_SetGroupVolume(CP_SOUND_GROUP_MUSIC, music_vol / 10.f);
	CP_Sound_SetGroupVolume(CP_SOUND_GROUP_SFX, sfx_vol / 10.f);

	scenes[SplashScene].init = SplashScene_init;
	scenes[SplashScene].update = SplashScene_update;
	scenes[SplashScene].exit = SplashScene_exit;

	scenes[MainMenuScene].init = MainMenu_init;
	scenes[MainMenuScene].update = MainMenu_update;
	scenes[MainMenuScene].exit = MainMenu_exit;

	scenes[Option_Scene].init = Options_init;
	scenes[Option_Scene].update = Options_update;
	scenes[Option_Scene].exit = Options_exit;

	scenes[HowToPlay_Scene].init = HowToPlay_init;
	scenes[HowToPlay_Scene].update = HowToPlay_update;
	scenes[HowToPlay_Scene].exit = HowToPlay_exit;

	scenes[HowToPlay2_Scene].init = HowToPlay2_init;
	scenes[HowToPlay2_Scene].update = HowToPlay2_update;
	scenes[HowToPlay2_Scene].exit = HowToPlay2_exit;

	scenes[Credit_Scene].init = Credits_init;
	scenes[Credit_Scene].update = Credits_update;
	scenes[Credit_Scene].exit = Credits_exit;

	scenes[Credit2_Scene].init = Credits2_init;
	scenes[Credit2_Scene].update = Credits2_update;
	scenes[Credit2_Scene].exit = Credits2_exit;

	scenes[Level_One].init = Desmond_init;
	scenes[Level_One].update = Desmond_update;
	scenes[Level_One].exit = Desmond_exit;

	scenes[Level_Two].init = Sarah_init;
	scenes[Level_Two].update = Sarah_update;
	scenes[Level_Two].exit = Sarah_exit;

	scenes[Level_Three].init = Warren_init;
	scenes[Level_Three].update = Warren_update;
	scenes[Level_Three].exit = Warren_exit;
}

int SceneManager_IsTransitioning(void)
{
	return startAnimate;
}

SceneIndex SceneManagerGetCurrentIndex()
{
	return index;
}

void SceneManagerSetNextScene(SceneIndex _index)
{
	index = _index != 0 ? _index : MainMenuScene;
	startAnimate = 1;
	goNextScene = 1;
	timer = 0;
	reverse = 0;
}

void SceneManagerRenderBlack()
{
	CP_Settings_Fill(CP_Color_Create(0, 0, 0, overlay));
	CP_Graphics_DrawRect(CP_System_GetWindowWidth() * .5f, CP_System_GetWindowHeight() * .5f, (float)CP_System_GetWindowWidth(), (float)CP_System_GetWindowHeight());
}

float SceneManager_GetOverlayPercentage(void)
{
	return overlay / 255.f;
}
