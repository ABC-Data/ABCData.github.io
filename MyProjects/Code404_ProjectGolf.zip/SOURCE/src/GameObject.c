﻿/*---------------------------------------------------------
 * file:	Audio.c
 * author:	Desmond peh han yong
 * email:	desmondhanyong.peh@digipen.edu
 *
 * brief:	Defination of GameObjects Fuunctions
 *
 * Copyright @ 2021 DigiPen, All rights reserved.
 *---------------------------------------------------------*/
#include "GameObject.h"
#include "Audio.h"

void GameObject_Init(GameObject* go)
{
	go->enable = 0;
	go->renderType = GO_NONE;
	go->colorType = GO_NOCOLOR;
	go->pos = CP_Vector_Zero();
	go->vel = CP_Vector_Zero();
	go->scale = CP_Vector_Zero();
	go->otherPos = CP_Vector_Zero();
	go->dir = CP_Vector_Zero();
	go->mass = 0;
	go->onSpecialTrigger = 0;
	go->otherRadius = 0;
	go->inWater = 0;
}

int IsCollided(GameObject* go1, GameObject* go2)
{
	GameObject* GOA = go1;
	GameObject* GOB = go2;

	if (GOA->renderType != GO_CIRCLE)
	{
		if (GOB->renderType != GO_CIRCLE)
			return BoxToBox(GOA, GOB);
		GOA = GOB;
		GOB = go1;
	}

	if (GOB->renderType == GO_CIRCLE)
		return CircleToCircle(GOA, GOB);

	return CircleToBox(GOA, GOB);
}

int CircleToCircle(GameObject* GOA, GameObject* GOB)
{
	float r = GOA->scale.x;
	float r2 = GOB->scale.x;

	CP_Vector RV = CP_Vector_Subtract(GOA->vel, GOB->vel);
	CP_Vector RP = CP_Vector_Subtract(GOA->pos, GOB->pos);

	return CP_Vector_DotProduct(RV, RP) < 0 && CP_Vector_Length(RP) < r + r2;
}

int CircleToBox(GameObject* GOA, GameObject* GOB)
{
	float r = GOA->scale.x;
	float h = GOB->scale.x;
	float l = GOB->scale.y;
	CP_Vector wallNormal = GOB->dir;
	CP_Vector wallRightNormal = CP_Vector_Set(wallNormal.y, -wallNormal.x);
	CP_Vector RP = CP_Vector_Subtract(GOA->pos, GOB->pos);

	if (CP_Vector_DotProduct(RP, wallNormal) > 0)
		wallNormal = CP_Vector_Negate(wallNormal);

	if (CP_Vector_DotProduct(RP, wallRightNormal) > 0)
		wallRightNormal = CP_Vector_Negate(wallRightNormal);

	return (CP_Vector_DotProduct(GOA->vel, wallNormal) > 0 || CP_Vector_DotProduct(GOA->vel, wallRightNormal) > 0) && fabsf(CP_Vector_DotProduct(RP, wallNormal)) < r + h * 0.5f && fabsf(CP_Vector_DotProduct(RP, wallRightNormal)) < r + l * 0.5f;
}

int BoxToBox(GameObject* GOA, GameObject* GOB)
{
	return 0;
}

void CollidedReaction(GameObject* go1, GameObject* go2)
{
	GameObject* GOA = go1;
	GameObject* GOB = go2;
	if (GOA->renderType != GO_CIRCLE)
	{
		if (GOB->renderType != GO_CIRCLE)
		{
			BoxToBoxReaction(GOA, GOB);
			return;
		}
		GOA = go2;
		GOB = go1;
	}

	if (GOB->renderType == GO_CIRCLE)
	{
		if (GOB->colorType == GO_PLAYER)
		{
			GOA = go2;
			GOB = go1;
		}

		if (GOA->colorType == GO_PLAYER && (GOB->colorType >= GO_WATER && GOB->colorType < GO_LAST))
		{
			SpecialReaction(GOA, GOB);
			return;
		}
		CircleToCircleReaction(GOA, GOB);
		return;
	}

	if (GOA->colorType == GO_PLAYER && (GOB->colorType >= GO_WATER && GOB->colorType < GO_LAST))
	{
		SpecialReaction(GOA, GOB);
		return;
	}

	CircleToBoxReaction(GOA, GOB);
}

void SpecialReaction(GameObject* GOA, GameObject* GOB)
{
	switch (GOB->colorType)
	{
	case GO_WATER:
		//GOA->pos = GOA->otherPos;
		GOA->inWater = 1;
		GOA->vel = CP_Vector_Zero();
		Play_SFX(SFX_WATER);
		return;
	case GO_SAND:
		GOA->onSpecialTrigger = 1;
		return;
	case GO_TUNNEL:
		GOA->pos = CP_Vector_Add(GOB->otherPos, CP_Vector_Scale(GOB->dir, GOB->otherRadius + GOA->scale.x));
		GOA->vel = CP_Vector_Scale(GOB->dir, CP_Vector_Length(GOA->vel));
		Play_SFX(SFX_TUNNEL);
		return;
	case GO_WIND:
		GOA->vel = CP_Vector_Add(GOA->vel, CP_Vector_Scale(GOB->otherPos, CP_System_GetDt()));
		return;
	case GO_GOAL:
		GOB->onSpecialTrigger = 1;
		Play_SFX(SFX_GOAL);
		return;
	}
}

void CircleToCircleReaction(GameObject* GOA, GameObject* GOB)
{
	switch (GOB->colorType)
	{
	case GO_MOVABLEBALL:
	{
		CP_Vector u1 = GOA->vel;
		CP_Vector u2 = GOB->vel;
		float m1 = GOA->mass;
		float m2 = GOB->mass;
		CP_Vector n = CP_Vector_Normalize(CP_Vector_Subtract(GOB->pos, GOA->pos));
		CP_Vector u1n = CP_Vector_Scale(n, CP_Vector_DotProduct(u1, n));
		CP_Vector u2n = CP_Vector_Scale(n, CP_Vector_DotProduct(u2, n));

		GOA->vel = CP_Vector_Add(u1, CP_Vector_Scale(CP_Vector_Subtract(u2n, u1n), ((2 * m2) / (m2 + m1))));
		/*if (CP_Vector_Length(GOA->vel) > BALLMAXSPEED)
			GOA->vel = CP_Vector_Scale(CP_Vector_Normalize(GOA->vel), BALLMAXSPEED);*/
		GOB->vel = CP_Vector_Add(u2, CP_Vector_Scale(CP_Vector_Subtract(u1n, u2n), ((2 * m1) / (m2 + m1))));
		/*if (CP_Vector_Length(GOB->vel) > BALLMAXSPEED)
			GOB->vel = CP_Vector_Scale(CP_Vector_Normalize(GOB->vel), BALLMAXSPEED);*/
		return;
	}
	case GO_WALL:
	{
		CP_Vector n = CP_Vector_Normalize(CP_Vector_Subtract(GOB->pos, GOA->pos));
		CP_Vector u = GOA->vel;

		GOA->vel = CP_Vector_Subtract(u, CP_Vector_Scale(CP_Vector_Scale(n, CP_Vector_DotProduct(u, n)), 2));
		Play_SFX(SFX_HIT_WALL);

		return;
	}
	}
}

void CircleToBoxReaction(GameObject* GOA, GameObject* GOB)
{
	switch (GOB->colorType)
	{
	case GO_WALL:
	{
		float r = GOA->scale.x;
		float h = GOB->scale.x;
		float l = GOB->scale.y;

		CP_Vector n, snap;
		CP_Vector u = GOA->vel;
		CP_Vector N = GOB->dir;
		CP_Vector NP = CP_Vector_Set(N.y, -N.x);
		CP_Vector RP = CP_Vector_Subtract(GOA->pos, GOB->pos);

		if (CP_Vector_DotProduct(RP, N) < 0)
			N = CP_Vector_Negate(N);

		if (CP_Vector_DotProduct(RP, NP) < 0)
			NP = CP_Vector_Negate(NP);

		/*
		* relativePos = playerPos - wallPos
		* if (forward collided)
		* snapPos = wallPos + (wallForward * (height * .5f + radius)) + proj(wallright, relativePos)
		* else
		* snapPos = wallPos + proj(wallForward, relativePos) + (wallright * (length * .5f + radius))
		* playerPos = playerPos + proj(playerVel, (snapPos - playerPos))
		*/
		float ph = CP_Vector_DotProduct(RP, N);
		float pl = CP_Vector_DotProduct(RP, NP);
		if (fabs(ph / (h * 0.5f + r)) < fabs(pl / (l * 0.5f + r)))
		{
			n = NP;
			snap = CP_Vector_Add(GOB->pos, CP_Vector_Add(CP_Vector_Scale(N, ph), CP_Vector_Scale(NP, (l * .5f + r))));
		}
		else
		{
			n = N;
			snap = CP_Vector_Add(GOB->pos, CP_Vector_Add(CP_Vector_Scale(N, (h * .5f + r)), CP_Vector_Scale(NP, pl)));
		}

		CP_Vector velNorm = CP_Vector_Normalize(u);
		GOA->pos = CP_Vector_Add(GOA->pos, CP_Vector_Scale(velNorm, CP_Vector_DotProduct(velNorm, CP_Vector_Subtract(snap, GOA->pos))));
		GOA->vel = CP_Vector_Subtract(u, CP_Vector_Scale(CP_Vector_Scale(n, CP_Vector_DotProduct(u, n)), 2));
		Play_SFX(SFX_HIT_WALL);
		return;
	}
	}
}

void BoxToBoxReaction(GameObject* GOA, GameObject* GOB)
{

}
